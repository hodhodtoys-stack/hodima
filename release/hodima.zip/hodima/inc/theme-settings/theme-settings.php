<?php
/**
 * Theme Settings — برند، اطلاعات تماس، فوتر و Google Analytics
 * Path: inc/theme-settings/theme-settings.php
 *
 * پیش از این، لوگو (با آدرس کامل دامنه سایت اصلی)، شماره تلفن، لینک
 * روبیکا و تلگرام، آدرس، نماد اعتماد، متن‌های فوتر و شناسه Google Analytics
 * مستقیم داخل header.php، footer.php و functions.php نوشته شده بودند:
 *   - قالب روی دامنه یا استیجینگ دیگری هنوز تصاویر را از سایت اصلی می‌کشید؛
 *   - آمار استیجینگ و بازدید مدیران با آمار واقعی سایت قاطی می‌شد؛
 *   - هر تغییر ساده (مثلا شماره تماس) ویرایش کد لازم داشت.
 *
 * حالا همه از «نمایش ← تنظیمات قالب هدیما» در پیشخوان خوانده می‌شوند.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const HODIMA_SETTINGS_OPTION = 'hodima_theme_settings';
const HODIMA_SETTINGS_PAGE   = 'hodima-settings';
const HODIMA_SETTINGS_HOOK   = 'toplevel_page_' . HODIMA_SETTINGS_PAGE; // شناسه صفحه پیشخوان (از 3.0.0 منوی سطح اول؛ قبلا appearance_page_…)
const HODIMA_TRUST_SLOTS     = 3; // تعداد نمادهای اعتماد فوتر

/* =========================================================================
 * ۱. تعریف فیلدها و خواندن تنظیمات
 * ========================================================================= */

/**
 * تعریف همه فیلدها: نوع، مقدار پیش‌فرض، برچسب و قاب (panel).
 *
 * تب هر فیلد از قابش می‌آید (hodima_settings_panels). کلید فیلدها نام ذخیره‌شده در
 * گزینه hodima_theme_settings است و نباید عوض شود؛ ترتیب و جای نمایش آزاد است.
 *
 * @return array<string, array{panel:string, type:string, label:string, default:mixed, group?:string, help?:string, placeholder?:string, wide?:bool}>
 */
function hodima_settings_fields(): array {
	return [
		// ── برند ────────────────────────────────────────────────────
		'logo_id'          => [ 'panel' => 'brand_logo', 'type' => 'image', 'label' => 'تصویر لوگو', 'default' => 0, 'preview' => 'header', 'help' => 'بهتر است نسخه SVG یا WebP با پس‌زمینه شفاف باشد. اگر خالی بماند نام سایت نمایش داده می‌شود.' ],
		'logo_invert'      => [ 'panel' => 'brand_logo', 'type' => 'toggle', 'label' => 'لوگو سفید نمایش داده شود', 'default' => true, 'help' => 'برای لوگوی رنگی روی پس‌زمینه تیره هدر. نتیجه را در پیش‌نمایش کنار تصویر ببینید.' ],

		// ── پالت رنگ برند (بازسازی قالب، مرحله ۵؛ توکن‌های assets/css/tokens.css) ──
		'color_primary'      => [ 'panel' => 'brand_palette', 'type' => 'color', 'label' => 'رنگ اصلی', 'default' => '#25316a', 'help' => 'هدر، دکمه‌ها و عنوان‌ها؛ نسخه تیره و سایه‌ها خودکار ساخته می‌شوند.' ],
		'color_secondary'    => [ 'panel' => 'brand_palette', 'type' => 'color', 'label' => 'رنگ دوم', 'default' => '#607bbd', 'help' => 'انتهای گرادیان هدر و لینک‌ها.' ],
		'color_third'        => [ 'panel' => 'brand_palette', 'type' => 'color', 'label' => 'رنگ سوم (روشن)', 'default' => '#b6c2f3', 'help' => 'زمینه‌ها و خطوط.' ],
		'color_accent'       => [ 'panel' => 'brand_palette', 'type' => 'color', 'label' => 'رنگ تأکید', 'default' => '#6a2b9a', 'help' => 'دکمه‌های مهم و برچسب‌ها.' ],
		'color_accent_light' => [ 'panel' => 'brand_palette', 'type' => 'color', 'label' => 'رنگ تأکید روشن', 'default' => '#a341c8', 'help' => 'انتهای گرادیان دکمه‌های مهم.' ],

		// ── تایپوگرافی (2.9.6؛ CSS: inc/typography.php، پیش‌فرض‌ها = tokens.css) ──
		...hodima_typography_fields(),

		// ── ظاهر عمومی (2.9.7؛ CSS: inc/appearance.php، پیش‌فرض‌ها = tokens.css) ──
		'radius_style'     => [ 'panel' => 'look_shape', 'type' => 'select', 'label' => 'گردی گوشه‌ها', 'default' => 'default', 'options' => [ 'sharp' => 'تیز (بدون گردی)', 'soft' => 'کم', 'default' => 'معمولی (پیش‌فرض)', 'round' => 'گرد' ], 'help' => 'کارت‌ها، کادرها، دکمه‌ها، فیلدها و تصویرهای کل سایت با هم. شکل‌های کاملا گرد (دکمه‌های کپسولی، دایره‌ها) همان می‌مانند.' ],
		'button_style'     => [ 'panel' => 'look_shape', 'type' => 'select', 'label' => 'سبک دکمه‌ها', 'default' => 'gradient', 'options' => [ 'gradient' => 'گرادیان رنگ اصلی و دوم (پیش‌فرض)', 'solid' => 'یک‌رنگ: رنگ اصلی', 'secondary' => 'یک‌رنگ: رنگ دوم', 'accent' => 'گرادیان رنگ تأکید' ], 'help' => 'دکمه‌های عمومی سایت و ووکامرس (افزودن به سبد، ثبت، ارسال فرم‌ها). دکمه‌های طراحی‌شده بخش‌ها (مثل «تسویه حساب») رنگ خودشان را دارند.' ],
		'container_width'  => [ 'panel' => 'look_width', 'type' => 'number', 'label' => 'بیشترین عرض محتوا (پیکسل)', 'default' => 1440, 'min' => 960, 'max' => 1920, 'help' => 'هدر، فوتر، فروشگاه، دسته‌ها، محصول و وبلاگ در صفحه‌های پهن‌تر از این عدد وسط صفحه می‌مانند. رایج: ۱۲۰۰ تا ۱۴۴۰.' ],

		// ── امکانات کاربری (2.9.8؛ inc/extras.php) — پیش‌فرض خاموش: ظاهر سایت تا روشن کردن همان ──
		'back_to_top'        => [ 'panel' => 'extras_top', 'type' => 'toggle', 'label' => 'دکمه «بازگشت به بالا»', 'default' => false, 'wide' => true, 'help' => 'بعد از کمی اسکرول پایین صفحه (سمت راست) ظاهر می‌شود؛ با کیبورد هم کار می‌کند.' ],
		'mobile_nav'         => [ 'panel' => 'extras_mobile_nav', 'type' => 'toggle', 'label' => 'نوار پایین موبایل', 'default' => false, 'wide' => true, 'help' => 'نوار ثابت پایین صفحه در موبایل و تبلت عمودی (عرض ۷۶۸ پیکسل و کمتر)، با «خانه» و موارد روشن پایین.' ],
		'mobile_nav_shop'    => [ 'panel' => 'extras_mobile_nav', 'type' => 'toggle', 'label' => 'فروشگاه', 'default' => true ],
		'mobile_nav_search'  => [ 'panel' => 'extras_mobile_nav', 'type' => 'toggle', 'label' => 'جستجو', 'default' => true, 'help' => 'کادر جستجوی هدر را باز می‌کند (اگر در تب «هدر» روشن باشد).' ],
		'mobile_nav_cart'    => [ 'panel' => 'extras_mobile_nav', 'type' => 'toggle', 'label' => 'سبد خرید', 'default' => true ],
		'mobile_nav_support' => [ 'panel' => 'extras_mobile_nav', 'type' => 'toggle', 'label' => 'پشتیبانی', 'default' => true, 'help' => 'پنجره پشتیبانی هدر (اگر در «اطلاعات تماس» راهی وارد شده باشد).' ],

		// ── هدر ─────────────────────────────────────────────────────
		'header_support_text'  => [ 'panel' => 'header_main', 'type' => 'text', 'label' => 'متن دکمه پشتیبانی', 'default' => 'پشتیبانی' ],
		'header_popup_title'   => [ 'panel' => 'header_main', 'type' => 'text', 'label' => 'عنوان پنجره پشتیبانی', 'default' => 'ارتباط با ما' ],
		'header_search'        => [ 'panel' => 'header_main', 'type' => 'toggle', 'label' => 'جستجو در هدر', 'default' => true, 'help' => 'کادر جستجوی محصولات و مقاله‌ها.' ],

		// ── فوتر ────────────────────────────────────────────────────
		'about_title'      => [ 'panel' => 'footer_about', 'type' => 'text', 'label' => 'عنوان ستون', 'default' => 'درباره ما' ],
		'about_text'       => [ 'panel' => 'footer_about', 'type' => 'textarea', 'label' => 'متن', 'default' => '' ],
		'guide_title'      => [ 'panel' => 'footer_guide', 'type' => 'text', 'label' => 'عنوان ستون', 'default' => 'راهنمای خرید' ],
		'guide_text'       => [ 'panel' => 'footer_guide', 'type' => 'textarea', 'label' => 'متن', 'default' => '', 'help' => 'آدرس تب «اطلاعات تماس» زیر همین متن نمایش داده می‌شود.' ],
		'consult_title'    => [ 'panel' => 'footer_consult', 'type' => 'text', 'label' => 'عنوان ستون فرم مشاوره', 'default' => 'مشاوره خرید' ],
		'copyright'        => [ 'panel' => 'footer_consult', 'type' => 'text', 'label' => 'متن کپی‌رایت (پایین فوتر)', 'default' => '', 'help' => 'اگر خالی بماند نام سایت نمایش داده می‌شود.' ],
		'trust_title'      => [ 'panel' => 'footer_trust', 'type' => 'text', 'label' => 'عنوان ستون', 'default' => 'نماد اعتماد' ],
		...hodima_trust_fields(),

		// ── صفحه اصلی (بخش‌ها: inc/theme-settings/home-layout-admin.php) ──
		'home_builder'     => [ 'panel' => 'home_mode', 'type' => 'toggle', 'label' => 'ساخت صفحه اصلی از چیدمان پایین', 'default' => false, 'wide' => true, 'help' => 'خاموش: صفحه اصلی مثل قبل از متن برگه صفحه اصلی (ویرایشگر برگه و شورت‌کدهایش) ساخته می‌شود. روشن: از بخش‌های پایین، به همان ترتیب.' ],
		'home_scroll_arrows' => [ 'panel' => 'home_mode', 'type' => 'toggle', 'label' => 'فلش قبلی/بعدی روی اسلایدرهای صفحه اصلی', 'default' => true, 'wide' => true, 'help' => 'دکمه‌های گرد روی محصولات، مقالات و دسته‌ها، در دسکتاپ و موبایل؛ وقتی اسکرول لازم نیست یا به ابتدا/انتها رسیده‌اید پنهان می‌شوند.' ],

		// ── فروشگاه و دسته‌ها ─────────────────────────────────────────
		'shop_title'       => [ 'panel' => 'shop_header', 'type' => 'text', 'label' => 'عنوان', 'default' => '', 'help' => 'اگر خالی بماند عنوان برگه فروشگاه ووکامرس نمایش داده می‌شود.' ],
		'shop_subtitle'    => [ 'panel' => 'shop_header', 'type' => 'text', 'label' => 'زیرعنوان', 'default' => '' ],
		'shop_features'    => [ 'panel' => 'shop_header', 'type' => 'textarea', 'label' => 'ویژگی‌ها (هر خط یک مورد)', 'default' => '', 'help' => 'مثلا: اصالت کالا، قیمت رقابتی، ارسال سریع — هر کدام در یک خط.' ],
		'shop_per_page'    => [ 'panel' => 'shop_list', 'type' => 'number', 'label' => 'تعداد محصول در هر صفحه', 'default' => 36, 'min' => 6, 'max' => 120, 'help' => 'مضرب ۱۲ (مثلا ۲۴، ۳۶، ۴۸) در همه اندازه‌های صفحه‌نمایش ردیف کامل می‌سازد. عدد خیلی بزرگ صفحه را روی موبایل کند می‌کند.' ],

		// ── صفحه محصول (قبلا ثابت در woocommerce/content-single-product.php) ──
		'product_price_empty'   => [ 'panel' => 'product_texts', 'type' => 'text', 'label' => 'جای قیمت، وقتی قیمت ندارد', 'default' => 'تماس بگیرید' ],
		'product_out_of_stock'  => [ 'panel' => 'product_texts', 'type' => 'text', 'label' => 'پیام محصول ناموجود (جای دکمه خرید)', 'default' => 'برای اطلاع از شارژ مجدد تماس بگیرید.' ],
		'product_podcast_label' => [ 'panel' => 'product_texts', 'type' => 'text', 'label' => 'برچسب پلیر پادکست', 'default' => 'پادکست' ],
		'product_show_podcast'  => [ 'panel' => 'product_sections', 'type' => 'toggle', 'label' => 'پادکست', 'default' => true ],
		'product_show_faq'      => [ 'panel' => 'product_sections', 'type' => 'toggle', 'label' => 'سوالات متداول', 'default' => true ],
		'product_show_video'    => [ 'panel' => 'product_sections', 'type' => 'toggle', 'label' => 'ویدیو', 'default' => true ],
		'product_show_reviews'  => [ 'panel' => 'product_sections', 'type' => 'toggle', 'label' => 'نظرات کاربران', 'default' => true ],
		'product_upsells_title' => [ 'panel' => 'product_upsells', 'type' => 'text', 'label' => 'عنوان بخش', 'default' => 'محصولات مشابه' ],
		'product_upsells_limit' => [ 'panel' => 'product_upsells', 'type' => 'number', 'label' => 'تعداد', 'default' => 6, 'min' => 0, 'max' => 24, 'help' => '۰ = بخش نمایش داده نشود.' ],
		// قیمت اعلام‌شده به گوگل؛ خواننده: Hodima SEO (inc/product-price.php). قیمت و نام ترب از 3.0.7 در «ابزارهای هدیما ← ترب» (Hodima SEO)
		'product_offer_price'   => [ 'panel' => 'product_price_feed', 'type' => 'select', 'label' => 'قیمتی که اعلام شود', 'default' => 'unit', 'options' => [ 'unit' => 'قیمت تک محصول', 'min_order' => 'مبلغ حداقل سفارش' ], 'help' => '«حداقل سفارش» همان مبلغی است که در ویرایش هر محصول (فیلد حداقل مبلغ سفارش) وارد کرده‌اید و صفحه محصول کنار قیمت نشان می‌دهد. محصولی که حداقل سفارش ندارد یا متغیر است، همیشه قیمت تک را اعلام می‌کند. به افزونه Hodima SEO نیاز دارد.' ],

		// ── وبلاگ (قبلا ثابت در archive-blog.php و single-post.php) ──
		'blog_columns'         => [ 'panel' => 'blog_page', 'type' => 'select', 'label' => 'تعداد ستون کارت‌ها (دسکتاپ)', 'default' => '4', 'options' => [ '4' => '۴ ستون (پیش‌فرض)', '3' => '۳ ستون', '2' => '۲ ستون' ], 'help' => 'در تبلت و موبایل خودکار کمتر می‌شود.' ],
		'blog_card_ratio'      => [ 'panel' => 'blog_page', 'type' => 'select', 'label' => 'شکل تصویر کارت', 'default' => '16-9', 'options' => [ '16-9' => 'عریض ۱۶:۹ (پیش‌فرض)', '4-3' => 'معمولی ۴:۳', '1-1' => 'مربع ۱:۱' ] ],
		'blog_per_page'        => [ 'panel' => 'blog_page', 'type' => 'number', 'label' => 'تعداد مقاله در هر صفحه', 'default' => 0, 'min' => 0, 'max' => 60, 'help' => 'برای صفحه وبلاگ، دسته‌ها، برچسب‌ها و آرشیوها. ۰ = همان عدد وردپرس (تنظیمات ← خواندن). با تغییر آن مقاله‌های هر صفحه (/page/N/) جابه‌جا می‌شوند.' ],
		'blog_featured'        => [ 'panel' => 'blog_page', 'type' => 'toggle', 'label' => 'مقاله ویژه بالای صفحه وبلاگ', 'default' => true, 'wide' => true, 'help' => 'اولین مقاله صفحه اول وبلاگ بزرگ و تمام‌عرض نمایش داده می‌شود. مقاله‌ای را که در ویرایش «سنجاق به صفحه اول وبلاگ» زده‌اید وردپرس اول می‌گذارد.' ],
		'blog_search'          => [ 'panel' => 'blog_page', 'type' => 'toggle', 'label' => 'جستجوی مقاله‌ها', 'default' => true, 'wide' => true, 'help' => 'کادر جستجوی مخصوص مقاله‌ها بالای صفحه وبلاگ، دسته‌ها و برچسب‌ها.' ],
		'blog_infinite_scroll' => [ 'panel' => 'blog_page', 'type' => 'toggle', 'label' => 'بارگذاری خودکار مقاله‌های بعدی با اسکرول', 'default' => true, 'help' => 'صفحه‌بندی واقعی برای موتورهای جستجو در هر حال سر جایش است.' ],
		'blog_card_excerpt'    => [ 'panel' => 'blog_page', 'type' => 'toggle', 'label' => 'خلاصه مقاله در کارت‌ها', 'default' => false, 'wide' => true, 'help' => 'چند خط اول هر مقاله (یا «خلاصه» ویرایشگر) زیر عنوان کارت.' ],
		'blog_cats_bar'        => [ 'panel' => 'blog_page', 'type' => 'toggle', 'label' => 'نوار دسته‌های وبلاگ', 'default' => true, 'wide' => true, 'help' => 'دسته‌های اصلی وبلاگ به‌صورت دکمه بالای مقاله‌ها در صفحه وبلاگ، دسته‌ها و برچسب‌ها؛ دسته جاری برجسته است. دسته «بدون دسته‌بندی» نمایش داده نمی‌شود.' ],
		'blog_cats_count'      => [ 'panel' => 'blog_page', 'type' => 'toggle', 'label' => 'تعداد مقاله کنار هر دسته', 'default' => true, 'wide' => true, 'help' => 'عدد کوچک کنار نام دسته در نوار دسته‌ها. اگر دسته‌ای زیردسته دارد، در صفحه آن دسته زیردسته‌هایش هم زیر نوار نمایش داده می‌شوند.' ],
		// صفحه هر مقاله (3.0.0): اطلاعات زیر عنوان و جمع شدن متن بلند
		'blog_meta_date'       => [ 'panel' => 'blog_post_meta', 'type' => 'toggle', 'label' => 'تاریخ انتشار', 'default' => true ],
		'blog_meta_updated'    => [ 'panel' => 'blog_post_meta', 'type' => 'toggle', 'label' => 'تاریخ به‌روزرسانی', 'default' => true, 'help' => 'فقط وقتی مقاله بعد از انتشار ویرایش شده باشد.' ],
		'blog_meta_reading'    => [ 'panel' => 'blog_post_meta', 'type' => 'toggle', 'label' => 'زمان مطالعه', 'default' => true, 'help' => 'تخمینی از تعداد کلمه‌ها؛ در کارت‌های وبلاگ هم.' ],
		'blog_meta_category'   => [ 'panel' => 'blog_post_meta', 'type' => 'toggle', 'label' => 'دسته مقاله (لینک)', 'default' => true, 'help' => 'دسته اصلی مقاله (همان دسته مسیر راهنما) با لینک به صفحه دسته.' ],
		'blog_meta_author'     => [ 'panel' => 'blog_post_meta', 'type' => 'toggle', 'label' => 'نویسنده', 'default' => false ],
		// امکانات صفحه مقاله (3.3.6)
		'blog_toc'             => [ 'panel' => 'blog_post_extra', 'type' => 'toggle', 'label' => 'فهرست مطالب', 'default' => true, 'help' => 'از تیترهای H2 و H3 متن مقاله، بالای متن (دست‌کم سه تیتر). روی لینک‌ها کلیک کنید تا به بخش بروید.' ],
		'blog_progress'        => [ 'panel' => 'blog_post_extra', 'type' => 'toggle', 'label' => 'نوار پیشرفت مطالعه', 'default' => true, 'help' => 'خط باریک بالای صفحه که با اسکرول در متن مقاله پر می‌شود.' ],
		'blog_tags'            => [ 'panel' => 'blog_post_extra', 'type' => 'toggle', 'label' => 'برچسب‌های مقاله', 'default' => true, 'help' => 'زیر متن مقاله، با لینک به صفحه هر برچسب.' ],
		'blog_share'           => [ 'panel' => 'blog_post_extra', 'type' => 'toggle', 'label' => 'اشتراک‌گذاری', 'default' => true, 'help' => 'کپی لینک، تلگرام و واتساپ.' ],
		'blog_author_box'      => [ 'panel' => 'blog_post_extra', 'type' => 'toggle', 'label' => 'کادر نویسنده', 'default' => true, 'help' => 'فقط وقتی نویسنده در پروفایلش «معرفی» نوشته باشد (کاربران ← پروفایل).' ],
		'blog_prev_next'       => [ 'panel' => 'blog_post_extra', 'type' => 'toggle', 'label' => 'مقاله قبلی و بعدی', 'default' => true, 'help' => 'پایین مقاله؛ اول از همان دسته، اگر نبود از کل وبلاگ.' ],
		'blog_content_collapse' => [ 'panel' => 'blog_post_content', 'type' => 'toggle', 'label' => 'متن بلند مقاله جمع شود («نمایش بیشتر»)', 'default' => true, 'wide' => true, 'help' => 'به افزونه Hodima Media نیاز دارد. خاموش: کل متن یک‌جا نمایش داده می‌شود.' ],
		'blog_content_height'  => [ 'panel' => 'blog_post_content', 'type' => 'number', 'label' => 'ارتفاع متن جمع‌شده (پیکسل)', 'default' => 400, 'min' => 200, 'max' => 1500 ],
		'blog_related_title'   => [ 'panel' => 'blog_related', 'type' => 'text', 'label' => 'عنوان', 'default' => 'مقالات مرتبط' ],
		'blog_related_limit'   => [ 'panel' => 'blog_related', 'type' => 'number', 'label' => 'تعداد', 'default' => 4, 'min' => 0, 'max' => 12, 'help' => '۰ = بخش نمایش داده نشود.' ],
		'blog_related_source'  => [ 'panel' => 'blog_related', 'type' => 'select', 'label' => 'کدام مقاله‌ها', 'default' => 'category', 'options' => [ 'category' => 'هم‌دسته (آخرین مقاله‌های همان دسته)', 'cluster' => 'هم‌خوشه (خوشه موضوعی افزونه سئو)، و اگر کم بود هم‌دسته' ] ],

		// ── صفحه ۴۰۴ (بازسازی قالب، مرحله ۴؛ قبلا ثابت در 404.php) ──
		'notfound_title'       => [ 'panel' => 'notfound_main', 'type' => 'text', 'label' => 'عنوان', 'default' => 'صفحه مورد نظر پیدا نشد!' ],
		'notfound_placeholder' => [ 'panel' => 'notfound_main', 'type' => 'text', 'label' => 'متن داخل کادر جستجو', 'default' => 'دنبال چه چیزی می‌گردید؟' ],
		'notfound_text'        => [ 'panel' => 'notfound_main', 'type' => 'textarea', 'label' => 'توضیح', 'default' => 'متأسفیم، به نظر می‌رسد آدرسی که وارد کرده‌اید اشتباه است یا این صفحه به مکان دیگری منتقل شده است.' ],
		'notfound_shop_button' => [ 'panel' => 'notfound_main', 'type' => 'toggle', 'label' => 'دکمه «رفتن به فروشگاه»', 'default' => true, 'help' => 'دکمه «صفحه اصلی» همیشه هست.' ],

		// ── اطلاعات تماس ───────────────────────────────────────────
		'phone'            => [ 'panel' => 'contact_phone', 'type' => 'tel', 'label' => 'شماره تماس', 'default' => '', 'placeholder' => '09120000000', 'help' => 'دکمه «تماس تلفنی» پنجره پشتیبانی.' ],
		'phone_2'          => [ 'panel' => 'contact_phone', 'type' => 'tel', 'label' => 'شماره تماس دوم', 'default' => '', 'placeholder' => '02100000000', 'help' => 'مثلا تلفن ثابت؛ در نسخه ماشین‌خوان (llms.txt) کنار شماره اصلی می‌آید.' ],
		'whatsapp_url'     => [ 'panel' => 'contact_messengers', 'type' => 'url', 'label' => 'واتس‌اپ', 'default' => '', 'placeholder' => 'https://wa.me/989120000000' ],
		'telegram_url'     => [ 'panel' => 'contact_messengers', 'type' => 'url', 'label' => 'تلگرام', 'default' => '', 'placeholder' => 'https://t.me/username' ],
		'rubika_url'       => [ 'panel' => 'contact_messengers', 'type' => 'url', 'label' => 'روبیکا', 'default' => '', 'placeholder' => 'https://rubika.ir/username' ],
		'address'          => [ 'panel' => 'contact_address', 'type' => 'text', 'label' => 'آدرس', 'default' => '' ],
		'map_url'          => [ 'panel' => 'contact_address', 'type' => 'url', 'label' => 'لینک نقشه', 'default' => '', 'placeholder' => 'https://maps.app.goo.gl/...' ],

		// ── شبکه‌های اجتماعی ─────────────────────────────────────────
		'social_hide_urls' => [ 'panel' => 'social_visibility', 'type' => 'urllist', 'label' => 'صفحه‌هایی که نوار در آن‌ها نمایش داده نشود', 'default' => '', 'placeholder' => "https://example.com/cart/\n/checkout/\n/product/*", 'help' => 'هر آدرس در یک خط؛ آدرس کامل صفحه یا فقط مسیر آن (مثلا /cart/). برای صفحه اصلی / و برای یک صفحه و همه زیرصفحه‌هایش * در انتها (مثلا /blog/*). پارامترهای بعد از ? در نظر گرفته نمی‌شوند.' ],

		// ── Google Analytics ───────────────────────────────────────
		'ga_id'            => [ 'panel' => 'analytics_ga', 'type' => 'ga', 'label' => 'شناسه اندازه‌گیری (Measurement ID)', 'default' => '', 'placeholder' => 'G-XXXXXXXXXX', 'help' => 'خالی = کد آمار چاپ نمی‌شود.' ],
		'ga_skip_editors'  => [ 'panel' => 'analytics_ga', 'type' => 'toggle', 'label' => 'بازدید مدیران و نویسندگان ثبت نشود', 'default' => true ],
		'ga_production'    => [ 'panel' => 'analytics_ga', 'type' => 'toggle', 'label' => 'فقط روی سایت اصلی (Production)', 'default' => true, 'help' => 'روی استیجینگ یا لوکال (WP_ENVIRONMENT_TYPE) کد آمار چاپ نمی‌شود تا آمار واقعی آلوده نشود.' ],

		// ── دامنه ویدئو: اتصال زودهنگام به دامنه پخش رسانه (نوسازی قالب، مرحله ۲ و ۴؛ قبلا dl.hodima.com ثابت در کد) ──
		'preconnect_hosts'      => [ 'panel' => 'speed_preconnect', 'type' => 'hostlist', 'label' => 'دامنه ویدئو و پادکست', 'default' => '', 'placeholder' => 'dl.example.com', 'help' => 'دامنه‌ای که فایل‌های ویدیو و پادکست سایت از آن پخش می‌شوند (مثلا هاست دانلود یا CDN)؛ اگر بیش از یکی است هر کدام در یک خط. در هر صفحه‌ای که ویدیو یا پادکستی از این دامنه دارد (کادر «رسانه»، صفحه ویدیو یا داخل متن نوشته)، مرورگر از همان ابتدای بارگذاری به آن وصل می‌شود تا پخش زودتر شروع شود؛ صفحه‌های دیگر اتصال اضافه نمی‌گیرند.' ],
		'code_head'             => [ 'panel' => 'code_main', 'type' => 'code', 'label' => 'کد داخل <head> همه صفحه‌ها', 'default' => '', 'placeholder' => '<meta name="…" content="…">', 'help_visible' => true, 'help' => 'مثلا تأیید مالکیت سایت یا کد ابزارهای آمار. فقط مدیر با دسترسی «HTML نامحدود» می‌تواند ذخیره کند. کد اشتباه ممکن است ظاهر یا کارکرد سایت را خراب کند.' ],
		'code_body_end'         => [ 'panel' => 'code_main', 'type' => 'code', 'label' => 'کد پایان صفحه (پیش از </body>)', 'default' => '', 'placeholder' => '<script>…</script>', 'help_visible' => true, 'help' => 'اسکریپت‌هایی که لازم نیست زود بارگذاری شوند (گفتگوی آنلاین، پیکسل‌ها). برای سرعت بهتر از کادر بالا این‌جاست.' ],
		'preconnect_media_auto' => [ 'panel' => 'speed_preconnect', 'type' => 'toggle', 'label' => 'تشخیص خودکار دامنه هر ویدیو و پادکست', 'default' => true, 'wide' => true, 'help' => 'دامنه ویدیو، کاور و پادکست هر صفحه (حتی آپارات و یوتیوب یا دامنه‌ای که بالا وارد نشده) خودکار تشخیص داده می‌شود. خاموش: فقط دامنه‌های کادر بالا.' ],
	];
}

/**
 * سه نماد اعتماد فوتر؛ هر کدام تصویر و لینک.
 * نماد اول همان کلیدهای قدیمی (trust_image_id / trust_url) را نگه می‌دارد تا
 * نماد ذخیره‌شده سایت بعد از به‌روزرسانی از دست نرود؛ بقیه پسوند _2 و _3 دارند.
 * @return array<string, array<string, mixed>>
 */
function hodima_trust_fields(): array {

	$fields = [];

	for ( $i = 1; $i <= HODIMA_TRUST_SLOTS; $i++ ) {
		$suffix = 1 === $i ? '' : "_{$i}";
		$fields[ "trust_image_id{$suffix}" ] = [ 'panel' => 'footer_trust', 'group' => "trust_{$i}", 'type' => 'image', 'label' => 'تصویر', 'default' => 0 ];
		$fields[ "trust_url{$suffix}" ]      = [ 'panel' => 'footer_trust', 'group' => "trust_{$i}", 'type' => 'url', 'label' => 'لینک', 'default' => '', 'placeholder' => 'https://', 'help' => 'صفحه اعتبارسنجی نماد.' ];
	}

	return $fields;
}

/**
 * فیلدهای تب «تایپوگرافی». پیش‌فرض‌ها دقیقا همان مقدارهای assets/css/tokens.css
 * است؛ hodima_typography_css() فقط مقدار متفاوت با پیش‌فرض را چاپ می‌کند.
 *
 * @return array<string, array<string, mixed>>
 */
function hodima_typography_fields(): array {

	// نام دلخواه فونت آپلودی در فهرست انتخاب (گزینه خام: hodima_setting() این‌جا حلقه بی‌پایان می‌سازد)
	$custom  = (string) ( ( (array) get_option( HODIMA_SETTINGS_OPTION, [] ) )['font_custom_name'] ?? '' );
	$custom  = hodima_typography_clean_font_name( $custom );
	$fonts   = [ 'vazirmatn' => 'وزیرمتن (همراه قالب)', 'custom' => '' !== $custom ? $custom . ' (فونت آپلودی)' : 'فونت آپلودی (قاب «فونت آپلودی»)', 'system' => 'فونت سیستم کاربر (بدون دانلود فونت)' ];
	$weights = hodima_typography_weights();
	$colors  = hodima_typography_color_options();
	$links   = $colors + [ 'custom' => 'دلخواه…' ]; // فقط لینک‌ها: رنگ آزاد با انتخاب‌گر (3.1.9)

	$fields = [
		'font_body'    => [ 'panel' => 'type_fonts', 'type' => 'select', 'label' => 'فونت متن', 'default' => 'vazirmatn', 'options' => $fonts, 'help' => 'متن، منو، دکمه‌ها و فرم‌ها.' ],
		'font_heading' => [ 'panel' => 'type_headings', 'type' => 'select', 'label' => 'فونت تیترها', 'default' => 'body', 'options' => [ 'body' => 'همان فونت متن' ] + $fonts, 'help' => 'H1 تا H6 و هر چه داخل تیتر است (مثلا لینک عنوان کارت‌ها).' ],

		'body_size'              => [ 'panel' => 'type_fonts', 'type' => 'number', 'label' => 'اندازه متن (پیکسل)', 'default' => 16, 'min' => 12, 'max' => 22, 'help' => 'متن مقاله‌ها، برگه‌ها و بدنه سایت. استاندارد خوانایی ۱۶ است.' ],
		'body_line_height'       => [ 'panel' => 'type_fonts', 'type' => 'number', 'label' => 'فاصله خطوط متن', 'default' => 1.8, 'min' => 1.2, 'max' => 2.4, 'step' => 0.05, 'help' => 'ضریب اندازه متن؛ برای فارسی ۱٫۷ تا ۲ خواناتر است.' ],
		'color_text'             => [ 'panel' => 'type_colors', 'type' => 'color', 'label' => 'رنگ متن و تیترها', 'default' => '#111111', 'help' => 'رنگ اصلی نوشته‌ها در کل سایت؛ تیترها جدا هم قابل تنظیم‌اند (قاب «تیترها»).' ],
		'link_color'             => [ 'panel' => 'type_colors', 'type' => 'select', 'label' => 'رنگ لینک‌ها', 'default' => 'secondary', 'options' => $links, 'swatch' => true, 'custom_key' => 'link_color_custom', 'help' => 'از پالت برند (با عوض شدن پالت، لینک‌ها هم عوض می‌شوند) یا «دلخواه»: هر رنگی با انتخاب‌گر یا کد رنگ، مستقل از پالت.' ],
		'link_color_custom'      => [ 'panel' => 'type_colors', 'type' => 'color', 'label' => 'رنگ دلخواه لینک‌ها', 'default' => '#607bbd', 'embedded' => true ], // در کارت «رنگ لینک‌ها» چاپ می‌شود
		'link_hover_color'       => [ 'panel' => 'type_colors', 'type' => 'select', 'label' => 'رنگ لینک با ماوس', 'default' => 'primary', 'options' => $links, 'swatch' => true, 'custom_key' => 'link_hover_color_custom', 'help' => 'وقتی نشانگر ماوس روی لینک می‌رود.' ],
		'link_hover_color_custom' => [ 'panel' => 'type_colors', 'type' => 'color', 'label' => 'رنگ دلخواه لینک با ماوس', 'default' => '#25316a', 'embedded' => true ],
		'content_link_underline' => [ 'panel' => 'type_colors', 'type' => 'toggle', 'label' => 'زیرخط لینک‌های داخل متن', 'default' => true, 'wide' => false, 'help' => 'لینک‌های داخل متن مقاله، برگه و توضیح محصول/دسته. استاندارد دسترس‌پذیری (WCAG): لینک نباید فقط با رنگ از متن جدا شود. دکمه‌ها و کارت‌ها زیرخط نمی‌گیرند.' ],
	];

	foreach ( hodima_typography_heading_defaults() as $level => $default ) {
		$group = "type_h{$level}";
		$fields[ "h{$level}_size" ]        = [ 'panel' => 'type_headings', 'group' => $group, 'type' => 'number', 'label' => "اندازه دسکتاپ H{$level} (پیکسل)", 'default' => $default['max'], 'min' => 10, 'max' => 80 ];
		$fields[ "h{$level}_size_mobile" ] = [ 'panel' => 'type_headings', 'group' => $group, 'type' => 'number', 'label' => "اندازه موبایل H{$level} (پیکسل)", 'default' => $default['min'], 'min' => 10, 'max' => 80 ];
		$fields[ "h{$level}_weight" ]      = [ 'panel' => 'type_headings', 'group' => $group, 'type' => 'select', 'label' => "وزن H{$level}", 'default' => (string) $default['weight'], 'options' => $weights ];
		$fields[ "h{$level}_line_height" ] = [ 'panel' => 'type_headings', 'group' => $group, 'type' => 'number', 'label' => "فاصله خطوط H{$level}", 'default' => $default['line_height'], 'min' => 1, 'max' => 2.4, 'step' => 0.05 ];
		$fields[ "h{$level}_color" ]       = [ 'panel' => 'type_headings', 'group' => $group, 'type' => 'select', 'label' => "رنگ H{$level}", 'default' => 'text', 'options' => $colors, 'swatch' => true ];
	}

	$fields['font_custom_name'] = [ 'panel' => 'type_custom', 'type' => 'text', 'label' => 'نام فونت', 'default' => '', 'placeholder' => 'مثلا ایران‌سنس', 'help' => 'نامی که در فهرست «فونت متن» و «فونت تیترها» می‌بینید (فقط حرف، عدد، فاصله، - و _). خالی: «فونت آپلودی».' ];

	foreach ( array_keys( $weights ) as $weight ) {
		$fields[ "font_custom_{$weight}" ] = [ 'panel' => 'type_custom', 'group' => "font_w{$weight}", 'type' => 'font', 'label' => 'فایل وزن ' . $weights[ $weight ], 'default' => 0 ];
	}

	return $fields;
}

/**
 * پیش‌فرض تیترها (همان tokens.css): اندازه دسکتاپ (max) و موبایل (min) به پیکسل.
 * تا 2.9.5: H1 ۲۷px، H2 ۱۶px، H3 تا H5 ۱۸px، H6 ۱۶px — H2 کوچک‌تر از H3 بود.
 *
 * @return array<int, array{max:int, min:int, weight:int, line_height:float}>
 */
function hodima_typography_heading_defaults(): array {
	return [
		1 => [ 'max' => 32, 'min' => 26, 'weight' => 700, 'line_height' => 1.5 ],
		2 => [ 'max' => 26, 'min' => 22, 'weight' => 700, 'line_height' => 1.5 ],
		3 => [ 'max' => 22, 'min' => 19, 'weight' => 700, 'line_height' => 1.5 ],
		4 => [ 'max' => 19, 'min' => 17, 'weight' => 700, 'line_height' => 1.5 ],
		5 => [ 'max' => 17, 'min' => 16, 'weight' => 700, 'line_height' => 1.5 ],
		6 => [ 'max' => 15, 'min' => 14, 'weight' => 700, 'line_height' => 1.5 ],
	];
}

/**
 * وزن‌های فونت (فایل‌های Vazirmatn همراه قالب همین هفت وزن‌اند).
 *
 * @return array<int, string>
 */
function hodima_typography_weights(): array {
	return [ 300 => 'نازک (۳۰۰)', 400 => 'معمولی (۴۰۰)', 500 => 'متوسط (۵۰۰)', 600 => 'نیم‌ضخیم (۶۰۰)', 700 => 'ضخیم (۷۰۰)', 800 => 'خیلی ضخیم (۸۰۰)', 900 => 'سیاه (۹۰۰)' ];
}

/**
 * رنگ‌های قابل انتخاب برای لینک و تیتر: متغیرهای پالت (نه رنگ ثابت)، تا با
 * عوض شدن پالت در تب «برند و رنگ‌ها» همه با هم عوض شوند.
 *
 * @return array<string, string>
 */
function hodima_typography_color_options(): array {
	return [ 'text' => 'رنگ متن', 'primary' => 'رنگ اصلی', 'secondary' => 'رنگ دوم', 'accent' => 'رنگ تأکید', 'accent-light' => 'رنگ تأکید روشن' ];
}

/** رنگ ذخیره‌شده یک گزینه hodima_typography_color_options() (text ← color_text، accent-light ← color_accent_light). */
function hodima_settings_palette_hex( string $option ): string {
	return (string) hodima_setting( 'color_' . str_replace( '-', '_', $option ) );
}

/** ارقام فارسی برای برچسب‌ها (مستقل از زبان پیشخوان). */
function hodima_fa_digits( int|string $value ): string {
	return strtr( (string) $value, [ '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹' ] );
}

/**
 * زیرگروه‌های داخل یک قاب (کارت هر نماد اعتماد، ردیف هر شبکه اجتماعی).
 *
 * @return array<string, array{title:string}>
 */
function hodima_settings_groups(): array {

	$groups = [];

	for ( $i = 1; $i <= HODIMA_TRUST_SLOTS; $i++ ) {
		$groups[ "trust_{$i}" ] = [ 'title' => 'نماد ' . hodima_fa_digits( $i ) ];
	}

	foreach ( array_keys( hodima_typography_heading_defaults() ) as $level ) {
		$groups[ "type_h{$level}" ] = [ 'title' => "H{$level}" ];
	}

	foreach ( hodima_typography_weights() as $weight => $label ) {
		$groups[ "font_w{$weight}" ] = [ 'title' => $label ];
	}

	return $groups;
}

/** گزینه فهرست شبکه‌های اجتماعی (فهرست پویا از ۳.۲.۳؛ تا ۳.۲.۲ هر شبکه دو کلید ثابت در گزینه تنظیمات بود). */
const HODIMA_SOCIAL_OPTION = 'hodima_social_links';
const HODIMA_SOCIAL_MAX    = 20; // سقف منطقی تعداد شبکه‌ها

/**
 * نام شبکه‌های ثابت قدیمی (۳.۲.۲ و پیش از آن) — فقط برای خواندن داده قدیمی؛ شبکه تازه را مدیر خودش پر می‌کند.
 *
 * @return array<string, string> شناسه => نام نمایشی
 */
function hodima_social_legacy_networks(): array {
	return [
		'instagram' => 'اینستاگرام',
		'telegram'  => 'تلگرام',
		'whatsapp'  => 'واتس‌اپ',
		'rubika'    => 'روبیکا',
		'aparat'    => 'آپارات',
		'eitaa'     => 'ایتا',
		'bale'      => 'بله',
		'youtube'   => 'یوتیوب',
		'linkedin'  => 'لینکدین',
	];
}

/**
 * گروه‌های منوی کناری صفحه تنظیمات.
 *
 * @return array<string, string>
 */
function hodima_settings_nav_groups(): array {
	return [
		'look'    => 'ظاهر سایت',
		'pages'   => 'صفحه‌ها',
		'contact' => 'ارتباط با مشتری',
		'tools'   => 'آمار و ابزارها',
	];
}

/**
 * بخش‌های صفحه تنظیمات؛ هر بخش یک تب. ترتیب = ترتیب منوی کناری.
 *
 * قبلا ده تب بی‌ترتیب در یک ردیف بودند (و در صفحه‌های کوچک‌تر آخرین تب‌ها
 * بیرون از کادر می‌افتادند)؛ «هدر و ۴۰۴» هم دو چیز بی‌ربط را در یک تب داشت.
 * حالا تب‌ها به ترتیب جای‌شان در سایت (بالا به پایین، بعد صفحه‌ها) و در
 * چهار گروه‌اند. کلید تب‌ها همان قبلی است (لینک‌های ?tab=… قدیمی کار می‌کنند).
 *
 * @return array<string, array{title:string, description:string, icon:string, nav:string}>
 */
function hodima_settings_sections(): array {
	return [
		'brand'     => [ 'nav' => 'look', 'title' => 'برند و رنگ‌ها', 'icon' => 'dashicons-art', 'description' => 'لوگوی هدر و پنج رنگ برند که کل سایت از آن‌ها ساخته می‌شود.' ],
		'typography' => [ 'nav' => 'look', 'title' => 'تایپوگرافی', 'icon' => 'dashicons-editor-textcolor', 'description' => 'فونت، اندازه و رنگ متن، لینک‌ها و تیترهای H1 تا H6 در کل سایت (و ویرایشگر نوشته‌ها).' ],
		'layout'    => [ 'nav' => 'look', 'title' => 'ظاهر عمومی', 'icon' => 'dashicons-layout', 'description' => 'گردی گوشه‌ها، سبک دکمه‌ها و عرض محتوای کل سایت.' ],
		'extras'    => [ 'nav' => 'look', 'title' => 'امکانات کاربری', 'icon' => 'dashicons-smartphone', 'description' => 'دکمه بازگشت به بالا و نوار پایین موبایل. هر دو تا روشن نشوند در سایت نمایش داده نمی‌شوند.' ],
		'header'    => [ 'nav' => 'look', 'title' => 'هدر', 'icon' => 'dashicons-editor-kitchensink', 'description' => 'نوار بالای همه صفحه‌ها. متن خالی به پیش‌فرض برمی‌گردد.' ],
		'footer'    => [ 'nav' => 'look', 'title' => 'فوتر', 'icon' => 'dashicons-table-row-after', 'description' => 'ستون‌های پایین همه صفحه‌ها. ستونی که محتوا نداشته باشد نمایش داده نمی‌شود.' ],
		'home'      => [ 'nav' => 'pages', 'title' => 'صفحه اصلی', 'icon' => 'dashicons-admin-home', 'description' => 'بخش‌های صفحه اصلی سایت: ترتیب، روشن/خاموش و تنظیمات هر بخش.' ],
		'shop'      => [ 'nav' => 'pages', 'title' => 'فروشگاه', 'icon' => 'dashicons-store', 'description' => 'سربرگ صفحه فروشگاه و تعداد محصول در هر صفحه.' ],
		'product'   => [ 'nav' => 'pages', 'title' => 'صفحه محصول', 'icon' => 'dashicons-products', 'description' => 'متن‌ها و بخش‌های صفحه هر محصول.' ],
		'blog'      => [ 'nav' => 'pages', 'title' => 'وبلاگ', 'icon' => 'dashicons-welcome-write-blog', 'description' => 'صفحه وبلاگ و کارت‌ها، اطلاعات و متن هر مقاله، و «مقالات مرتبط».' ],
		'notfound'  => [ 'nav' => 'pages', 'title' => 'صفحه ۴۰۴', 'icon' => 'dashicons-warning', 'description' => 'صفحه‌ای که بازدیدکننده با آدرس اشتباه یا حذف‌شده می‌بیند. متن خالی به پیش‌فرض برمی‌گردد.' ],
		'contact'   => [ 'nav' => 'contact', 'title' => 'اطلاعات تماس', 'icon' => 'dashicons-phone', 'description' => 'در پنجره «پشتیبانی» هدر و فوتر نمایش داده می‌شود. هر گزینه خالی نمایش داده نمی‌شود.' ],
		'social'    => [ 'nav' => 'contact', 'title' => 'شبکه‌های اجتماعی', 'icon' => 'dashicons-share', 'description' => 'نوار شبکه‌های اجتماعی بالای فوتر همه صفحه‌ها. بدون هیچ شبکه‌ای نوار نمایش داده نمی‌شود.' ],
		'analytics' => [ 'nav' => 'tools', 'title' => 'Google Analytics', 'icon' => 'dashicons-chart-area', 'description' => 'کد آمار GA4 با بارگذاری async و بدون مسدود کردن رندر صفحه اضافه می‌شود.' ],
		'speed'     => [ 'nav' => 'tools', 'title' => 'دامنه ویدئو', 'icon' => 'dashicons-video-alt3', 'description' => 'دامنه‌ای که ویدیو و پادکست‌های سایت از آن پخش می‌شوند؛ مرورگر در صفحه‌های دارای ویدیو از ابتدا به آن وصل می‌شود تا پخش زودتر شروع شود.' ],
		'code'      => [ 'nav' => 'tools', 'title' => 'کد سفارشی', 'icon' => 'dashicons-editor-code', 'description' => 'کد HTML یا اسکریپت دلخواه در همه صفحه‌های سایت (نه پیشخوان).' ],
		'backup'    => [ 'nav' => 'tools', 'title' => 'پشتیبان تنظیمات', 'icon' => 'dashicons-backup', 'description' => 'همه تنظیمات این صفحه (و چیدمان صفحه اصلی) در یک فایل؛ برای نگه‌داری یا انتقال به سایت دیگر.' ],
	];
}

/**
 * قاب‌های هر تب (کارت با عنوان و توضیح). ترتیب = ترتیب نمایش در تب.
 *
 *   layout: grid (پیش‌فرض) | toggles (کلیدها کنار هم) | swatches (رنگ‌ها) |
 *           cards (زیرگروه‌ها کنار هم: نمادهای اعتماد) |
 *           rows (هر زیرگروه یک ردیف با ستون‌های هم‌تراز: شبکه‌ها)
 *   half:   در صفحه پهن، نصف عرض (دو قاب کوچک کنار هم)
 *
 * @return array<string, array{section:string, title:string, help?:string, icon?:string, layout?:string, half?:bool, columns?:list<string>}>
 */
function hodima_settings_panels(): array {
	return [
		'brand_logo'         => [ 'section' => 'brand', 'title' => 'لوگو', 'icon' => 'dashicons-format-image', 'layout' => 'logo', 'help' => 'لوگوی هدر سایت؛ پیش‌نمایش روی رنگ هدر است.' ],
		'brand_palette'      => [ 'section' => 'brand', 'title' => 'پالت رنگ برند', 'icon' => 'dashicons-admin-appearance', 'layout' => 'swatches', 'help' => 'رنگ‌های کل سایت (و صفحه‌های تنظیمات پیشخوان) از این پنج رنگ ساخته می‌شوند. بعد از ذخیره، کش لایت‌اسپید خودکار پاک می‌شود.' ],

		'type_preview'       => [ 'section' => 'typography', 'title' => 'پیش‌نمایش', 'icon' => 'dashicons-visibility', 'layout' => 'typepreview', 'collapsible' => true, 'help' => 'برای دیدن، باز کنید. با هر تغییر پایین همین‌جا به‌روز می‌شود (پیش از ذخیره). اندازه تیترها در عرض همین کادر نمایش داده می‌شود.' ],
		'type_fonts'         => [ 'section' => 'typography', 'title' => 'فونت و اندازه متن', 'icon' => 'dashicons-editor-textcolor', 'help' => 'فایل‌های وزیرمتن (هفت وزن ۳۰۰ تا ۹۰۰) همراه قالب‌اند و از همین سایت بارگذاری می‌شوند. مرورگر هر وزن را فقط وقتی دانلود می‌کند که در صفحه به کار رفته باشد.' ],
		'type_colors'        => [ 'section' => 'typography', 'title' => 'رنگ متن و لینک‌ها', 'icon' => 'dashicons-art', 'layout' => 'colors', 'help' => 'رنگ اصلی نوشته‌ها، رنگ لینک‌ها و حالت زیر نشانگر ماوس. رنگ لینک‌ها از پالت برند است و با عوض شدن پالت، خودکار عوض می‌شود.' ],
		'type_headings'      => [ 'section' => 'typography', 'title' => 'تیترها (H1 تا H6)', 'icon' => 'dashicons-heading', 'layout' => 'rows', 'headings' => true, 'columns' => [ 'تیتر', 'اندازه دسکتاپ (px)', 'اندازه موبایل (px)' ], 'columns_more' => [ 'تیتر', 'وزن', 'فاصله خطوط', 'رنگ' ], 'help' => 'اندازه از «موبایل» (صفحه ۳۹۰ پیکسل) تا «دسکتاپ» (۱۲۰۰ پیکسل و بیشتر) نرم تغییر می‌کند. پایه تیترهای داخل متن مقاله، برگه، توضیح محصول و دسته است؛ H1 عنوان همه صفحه‌ها هم هست (محصول، مقاله، دسته، فروشگاه، وبلاگ، برگه، جستجو، ویدیو). تیترهای طراحی‌شده بخش‌ها (کارت محصول، فوتر، عنوان بخش‌های صفحه اصلی) اندازه خودشان را دارند. ترتیب درست: هر سطح کوچک‌تر از سطح بالاتر.' ],
		'type_custom'        => [ 'section' => 'typography', 'title' => 'فونت آپلودی', 'icon' => 'dashicons-upload', 'layout' => 'tiles', 'collapsible' => true, 'force_open' => 'hodima_typography_custom_selected', 'open_on' => [ 'font_body', 'font_heading' ], 'primary' => [ 'font_w400', 'font_w700' ], 'help' => 'برای فونتی که مجوز استفاده در وب را دارید (مثلا ایران‌سنس یا یکان‌بخ). فایل woff2 هر وزن را از کتابخانه رسانه انتخاب یا آپلود کنید؛ وزن «معمولی (۴۰۰)» لازم است و وزن خالی از نزدیک‌ترین وزن موجود ساخته می‌شود. بعد در قاب «فونت‌ها» گزینه «فونت آپلودی» را انتخاب کنید.' ],

		'look_preview'       => [ 'section' => 'layout', 'title' => 'پیش‌نمایش', 'icon' => 'dashicons-visibility', 'layout' => 'lookpreview', 'help' => 'نمونه کارت و دکمه با انتخاب‌های پایین (پیش از ذخیره).' ],
		'look_shape'         => [ 'section' => 'layout', 'title' => 'گوشه‌ها و دکمه‌ها', 'icon' => 'dashicons-art', 'half' => true ],
		'look_width'         => [ 'section' => 'layout', 'title' => 'عرض صفحه', 'icon' => 'dashicons-editor-expand', 'half' => true ],

		'header_main'        => [ 'section' => 'header', 'title' => 'پشتیبانی و جستجو', 'icon' => 'dashicons-format-chat', 'help' => 'دکمه پشتیبانی فقط وقتی دیده می‌شود که در تب «اطلاعات تماس» دست‌کم یک راه ارتباطی وارد شده باشد.' ],

		'footer_about'       => [ 'section' => 'footer', 'title' => 'ستون «درباره ما»', 'icon' => 'dashicons-info', 'half' => true ],
		'footer_guide'       => [ 'section' => 'footer', 'title' => 'ستون «راهنمای خرید»', 'icon' => 'dashicons-sos', 'half' => true ],
		'footer_trust'       => [ 'section' => 'footer', 'title' => 'ستون «نماد اعتماد»', 'icon' => 'dashicons-shield', 'layout' => 'cards', 'help' => 'تا سه نماد (مثلا اینماد، ساماندهی، اتحادیه). نمادهای دارای تصویر به همین ترتیب کنار هم نمایش داده می‌شوند؛ نماد بدون تصویر نادیده گرفته می‌شود.' ],
		'footer_consult'     => [ 'section' => 'footer', 'title' => 'فرم مشاوره و کپی‌رایت', 'icon' => 'dashicons-edit' ],

		'home_mode'          => [ 'section' => 'home', 'title' => 'روش ساخت صفحه اصلی', 'icon' => 'dashicons-admin-generic' ],
		// قاب «بخش‌های صفحه اصلی» را home-layout-admin.php می‌سازد

		'shop_header'        => [ 'section' => 'shop', 'title' => 'سربرگ صفحه فروشگاه', 'icon' => 'dashicons-cover-image', 'help' => 'زیرعنوان و ویژگی‌های خالی نمایش داده نمی‌شوند.' ],
		'shop_list'          => [ 'section' => 'shop', 'title' => 'فهرست محصولات', 'icon' => 'dashicons-grid-view', 'help' => 'فروشگاه، دسته‌ها و برچسب‌های محصول.' ],

		'product_texts'      => [ 'section' => 'product', 'title' => 'متن‌ها', 'icon' => 'dashicons-editor-textcolor' ],
		'product_sections'   => [ 'section' => 'product', 'title' => 'بخش‌های صفحه محصول', 'icon' => 'dashicons-visibility', 'layout' => 'toggles', 'help' => 'بخش خاموش برای همه محصولات پنهان می‌شود؛ بخش روشن فقط وقتی محتوا دارد دیده می‌شود (کادر «رسانه» هر محصول و نظرات ووکامرس).' ],
		'product_price_feed' => [ 'section' => 'product', 'title' => 'قیمت در اسکیما (گوگل)', 'icon' => 'dashicons-tag', 'help' => 'عددی که گوگل (اسکیما)، پیش‌نمایش لینک در شبکه‌های اجتماعی (متاتگ قیمت) و فایل‌های هوش مصنوعی (llms) به‌عنوان قیمت محصول می‌بینند. قیمت در صفحه محصول، سبد و پرداخت عوض نمی‌شود. بعد از تغییر، کش لایت‌اسپید را پاک کنید. قیمت و نام محصولات در ترب: «ابزارهای هدیما ← ترب».' ],
		'product_upsells'    => [ 'section' => 'product', 'title' => 'محصولات پیشنهادی (Upsell)', 'icon' => 'dashicons-cart', 'help' => 'محصولاتی که در ویرایش محصول، بخش «محصولات مرتبط ← افزایش فروش» انتخاب می‌کنید.' ],

		'blog_page'          => [ 'section' => 'blog', 'title' => 'صفحه وبلاگ', 'icon' => 'dashicons-welcome-write-blog' ],
		'blog_post_meta'     => [ 'section' => 'blog', 'title' => 'اطلاعات زیر عنوان مقاله', 'icon' => 'dashicons-calendar-alt', 'layout' => 'toggles', 'help' => 'تاریخ، زمان مطالعه و نویسنده به خواننده و گوگل نشان می‌دهد مقاله تازه و معتبر است.' ],
		'blog_post_extra'    => [ 'section' => 'blog', 'title' => 'امکانات صفحه مقاله', 'icon' => 'dashicons-admin-generic', 'layout' => 'toggles', 'help' => 'فهرست مطالب، نوار پیشرفت، برچسب‌ها، اشتراک‌گذاری، کادر نویسنده و مقاله قبلی/بعدی.' ],
		'blog_post_content'  => [ 'section' => 'blog', 'title' => 'متن مقاله', 'icon' => 'dashicons-editor-expand' ],
		'blog_related'       => [ 'section' => 'blog', 'title' => 'مقالات مرتبط', 'icon' => 'dashicons-admin-links', 'help' => 'فهرست مقاله‌های دیگر زیر هر مقاله، بعد از دیدگاه‌ها.' ],

		'notfound_main'      => [ 'section' => 'notfound', 'title' => 'متن‌ها و دکمه‌ها', 'icon' => 'dashicons-editor-textcolor' ],

		'contact_phone'      => [ 'section' => 'contact', 'title' => 'تلفن', 'icon' => 'dashicons-phone' ],
		'contact_messengers' => [ 'section' => 'contact', 'title' => 'پیام‌رسان‌ها', 'icon' => 'dashicons-format-chat', 'help' => 'دکمه‌های پنجره پشتیبانی هدر.' ],
		'contact_address'    => [ 'section' => 'contact', 'title' => 'آدرس', 'icon' => 'dashicons-location' ],

		'social_visibility'  => [ 'section' => 'social', 'title' => 'نمایش در صفحه‌ها', 'icon' => 'dashicons-visibility' ],

		'analytics_ga'       => [ 'section' => 'analytics', 'title' => 'Google Analytics 4', 'icon' => 'dashicons-chart-area' ],

		'extras_top'         => [ 'section' => 'extras', 'title' => 'بازگشت به بالا', 'icon' => 'dashicons-arrow-up-alt', 'half' => true ],
		'extras_mobile_nav'  => [ 'section' => 'extras', 'title' => 'نوار پایین موبایل', 'icon' => 'dashicons-smartphone', 'layout' => 'toggles', 'help' => '«خانه» همیشه هست؛ فروشگاه و سبد فقط با ووکامرس. بیشتر از ۵ مورد نیست تا روی صفحه کوچک جا شود.' ],
		'code_main'          => [ 'section' => 'code', 'title' => 'کد دلخواه', 'icon' => 'dashicons-editor-code' ],
		'backup_main'        => [ 'section' => 'backup', 'title' => 'دریافت و بازگردانی', 'icon' => 'dashicons-backup', 'layout' => 'backup', 'help' => 'تصویرها (لوگو، نمادها، فونت‌ها) با شناسه کتابخانه رسانه ذخیره می‌شوند؛ روی سایت دیگر اگر همان فایل نباشد خالی می‌مانند و باید دوباره انتخاب شوند.' ],
		'speed_preconnect'   => [ 'section' => 'speed', 'title' => 'دامنه پخش ویدیو و پادکست', 'icon' => 'dashicons-video-alt3', 'help' => 'اگر ویدیو و پادکست‌ها روی دامنه جدا (هاست دانلود یا CDN) هستند، اتصال زودهنگام چند صدم ثانیه از شروع پخش کم می‌کند. دامنه را خودتان وارد کنید یا از «دامنه‌های پیدا شده» زیر کادر انتخاب کنید.' ],
	];
}

/**
 * همه تنظیمات، ادغام‌شده با پیش‌فرض‌ها.
 *
 * @return array<string, mixed>
 */
function hodima_settings(): array {

	static $cache = null;

	if ( null !== $cache ) {
		return $cache;
	}

	$defaults = array_map( static fn( array $field ): mixed => $field['default'], hodima_settings_fields() );
	$stored   = get_option( HODIMA_SETTINGS_OPTION, [] );
	$settings = array_merge( $defaults, is_array( $stored ) ? array_intersect_key( $stored, $defaults ) : [] );

	// عنوان خالی (مثلا عنوان ستون فوتر) به پیش‌فرض برمی‌گردد تا تیتر خالی چاپ نشود
	foreach ( $defaults as $key => $default ) {
		if ( is_string( $default ) && '' !== $default && '' === trim( (string) $settings[ $key ] ) ) {
			$settings[ $key ] = $default;
		}
	}

	$cache = $settings;

	return $cache;
}

/** یک مقدار از تنظیمات. */
function hodima_setting( string $key ): mixed {
	return hodima_settings()[ $key ] ?? null;
}

/**
 * تب یک فیلد (از قابش).
 *
 * @param array<string, mixed> $field
 */
function hodima_settings_field_section( array $field ): string {
	return (string) ( hodima_settings_panels()[ $field['panel'] ?? '' ]['section'] ?? '' );
}

/**
 * نام کامل فیلد برای پیام خطا، مثل «فوتر › نماد ۲ › لینک».
 * برچسب‌ها داخل قاب کوتاه‌اند («لینک»)؛ بیرون از قاب مبهم می‌شدند.
 */
function hodima_settings_field_label( string $key ): string {

	$field = hodima_settings_fields()[ $key ] ?? null;
	if ( null === $field ) {
		return $key;
	}

	$panel = hodima_settings_panels()[ $field['panel'] ] ?? [];
	$parts = [
		hodima_settings_sections()[ hodima_settings_field_section( $field ) ]['title'] ?? '',
		isset( $field['group'] ) ? ( hodima_settings_groups()[ $field['group'] ]['title'] ?? '' ) : ( $panel['title'] ?? '' ),
		$field['label'],
	];

	// بدون تکه خالی و تکرار پشت‌سرهم (ردیف «اینستاگرام» با برچسب «اینستاگرام»)
	$parts = array_values( array_filter( $parts, static fn( string $part ): bool => '' !== $part ) );
	$parts = array_filter( $parts, static fn( string $part, int $i ): bool => 0 === $i || $part !== $parts[ $i - 1 ], ARRAY_FILTER_USE_BOTH );

	return implode( ' › ', $parts );
}

/* =========================================================================
 * ۲. ثبت تنظیمات و صفحه پیشخوان
 * ========================================================================= */

add_action( 'admin_init', static function (): void {
	register_setting( 'hodima_theme_settings_group', HODIMA_SETTINGS_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'hodima_settings_sanitize',
		'default'           => [],
		'show_in_rest'      => false,
	] );
} );

/*
 * منوی سطح اول درست بالای «نمایش» (جایگاه ۶۰؛ ۵۹ جداکننده است). تا 2.9.9 زیرمنوی
 * «نمایش» بود (themes.php?page=hodima-settings)؛ آن آدرس (نشانک‌ها، لینک افزونه‌های
 * قدیمی) با همه پارامترهایش به آدرس تازه می‌رود.
 */
add_action( 'admin_menu', static function (): void {
	add_menu_page(
		'تنظیمات قالب هدیما', // عنوان تب مرورگر
		'قالب هدیما',          // نام منوی پیشخوان
		'manage_options',
		HODIMA_SETTINGS_PAGE,
		'hodima_settings_render_page',
		'dashicons-admin-customizer',
		59.5
	);
} );

add_action( 'admin_init', static function (): void {
	global $pagenow;

	if ( 'themes.php' === $pagenow && HODIMA_SETTINGS_PAGE === ( $_GET['page'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- فقط ریدایرکت آدرس قدیمی
		wp_safe_redirect( hodima_settings_url( array_map( 'sanitize_text_field', wp_unslash( array_diff_key( $_GET, [ 'page' => 1 ] ) ) ) ), 301 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- همان پارامترها (tab، settings-updated)
		exit;
	}
} );

/**
 * آدرس صفحه تنظیمات قالب (با پارامتر دلخواه، مثلا [ 'tab' => 'blog' ]).
 *
 * @param array<string, mixed> $args
 */
function hodima_settings_url( array $args = [] ): string {
	return add_query_arg( [ 'page' => HODIMA_SETTINGS_PAGE, ...$args ], admin_url( 'admin.php' ) );
}

/**
 * پاک‌سازی و اعتبارسنجی همه فیلدها.
 * مقدار نامعتبر رد و به کاربر اطلاع داده می‌شود؛ مقدار قبلی حفظ نمی‌شود
 * تا خطا بی‌صدا پنهان نماند.
 *
 * @param mixed $input
 * @return array<string, mixed>
 */
function hodima_settings_sanitize( $input ): array {

	/*
	 * بدون wp_unslash: options.php پیش از update_option خودش unslash می‌کند و این
	 * callback داده unslash‌شده می‌گیرد. تا 2.9.7 دوباره unslash می‌شد و هر «\» در
	 * متن تنظیمات (و از 2.9.8 در کد سفارشی، مثل "\n" در اسکریپت) پاک می‌شد.
	 */
	$input  = is_array( $input ) ? $input : [];
	$clean  = [];

	foreach ( hodima_settings_fields() as $key => $field ) {

		// رفتار هر نوع: enum Hodima_Setting_Type (inc/classes)؛ نوع ناشناخته مثل قبل = متن
		$clean[ $key ] = hodima_setting_type( $field )->sanitize( $key, $field, $input[ $key ] ?? null );
	}

	// «فونت آپلودی» بدون فایل (inc/typography.php)
	return hodima_typography_validate( $clean );
}

/**
 * نوع یک فیلد تنظیمات.
 *
 * @param array<string, mixed> $field
 */
function hodima_setting_type( array $field ): Hodima_Setting_Type {
	return Hodima_Setting_Type::tryFrom( (string) ( $field['type'] ?? '' ) ) ?? Hodima_Setting_Type::Text;
}

/** رنگ: #abc → #aabbcc (input type=color فقط شش رقمی می‌پذیرد)؛ نامعتبر = پیش‌فرض. */
function hodima_settings_sanitize_color( mixed $raw, string $fallback ): string {

	$hex = sanitize_hex_color( is_string( $raw ) ? trim( $raw ) : '' );

	return $hex ? hodima_rgb_hex( hodima_hex_rgb( $hex ) ) : strtolower( $fallback );
}

function hodima_settings_sanitize_image( mixed $raw ): int {
	$id = absint( is_scalar( $raw ) ? $raw : 0 );
	return ( $id && wp_attachment_is_image( $id ) ) ? $id : 0;
}

/**
 * عدد در بازه min/max؛ خالی/نامعتبر = پیش‌فرض. با step اعشاری (مثلا ۰٫۰۵ برای
 * فاصله خطوط) عدد اعشاری گرد‌شده به همان گام، وگرنه صحیح (رفتار قبلی همه
 * فیلدهای عددی). ارقام فارسی هم پذیرفته می‌شوند.
 *
 * @param array<string, mixed> $field
 */
function hodima_settings_sanitize_number( array $field, mixed $raw ): int|float {

	$step    = (float) ( $field['step'] ?? 1 );
	$decimal = $step > 0 && floor( $step ) !== $step;
	$raw     = is_string( $raw ) ? strtr( trim( $raw ), [ '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٫' => '.', '/' => '.' ] ) : $raw;

	if ( ! is_numeric( $raw ) ) {
		return $decimal ? (float) $field['default'] : (int) $field['default'];
	}

	if ( ! $decimal ) {
		return min( (int) ( $field['max'] ?? PHP_INT_MAX ), max( (int) ( $field['min'] ?? 0 ), (int) $raw ) );
	}

	$value = min( (float) ( $field['max'] ?? PHP_FLOAT_MAX ), max( (float) ( $field['min'] ?? 0 ), (float) $raw ) );

	return round( round( $value / $step ) * $step, 4 );
}

/** عدد برای نمایش در فیلد و CSS: «1.80» → «1.8»، «16.0» → «16». */
function hodima_number_text( int|float $value ): string {
	return rtrim( rtrim( number_format( (float) $value, 4, '.', '' ), '0' ), '.' );
}

/** فایل فونت (woff2/woff) از کتابخانه رسانه؛ هر چیز دیگر = ۰. */
function hodima_settings_sanitize_font( mixed $raw ): int {
	$id = absint( is_scalar( $raw ) ? $raw : 0 );
	return ( $id && hodima_is_font_attachment( $id ) ) ? $id : 0;
}

/**
 * کد خام (تب «کد سفارشی»): فقط کاربری که اجازه HTML نامحدود دارد (unfiltered_html؛
 * در چندسایته فقط مدیر کل) می‌تواند عوضش کند؛ برای بقیه مقدار قبلی می‌ماند.
 */
function hodima_settings_sanitize_code( string $key, mixed $raw ): string {

	$raw     = is_string( $raw ) ? trim( $raw ) : '';
	$stored  = get_option( HODIMA_SETTINGS_OPTION, [] );
	$current = is_array( $stored ) ? (string) ( $stored[ $key ] ?? '' ) : '';

	if ( $raw !== $current && ! current_user_can( 'unfiltered_html' ) ) {
		add_settings_error( HODIMA_SETTINGS_OPTION, "denied_{$key}", sprintf( '«%s» ذخیره نشد: حساب شما اجازه افزودن کد HTML/اسکریپت را ندارد.', hodima_settings_field_label( $key ) ) );
		return $current;
	}

	return $raw;
}

function hodima_settings_sanitize_url( string $key, mixed $raw ): string {

	$raw = is_string( $raw ) ? trim( $raw ) : '';
	if ( '' === $raw ) {
		return '';
	}

	$url = esc_url_raw( $raw, [ 'https', 'http' ] );
	if ( '' === $url || ! wp_http_validate_url( $url ) ) {
		add_settings_error( HODIMA_SETTINGS_OPTION, "invalid_{$key}", sprintf( 'آدرس وارد شده برای «%s» معتبر نیست و ذخیره نشد.', hodima_settings_field_label( $key ) ) );
		return '';
	}

	return $url;
}

/**
 * فهرست آدرس (هر خط یکی): آدرس کامل http(s) یا مسیر با / ابتدایی، و * فقط در انتها.
 * «hodhodli.com/cart» به آدرس کامل و «cart/» به مسیر تبدیل می‌شود؛ خط تکراری یا
 * نامعتبر حذف و به کاربر اطلاع داده می‌شود.
 */
function hodima_settings_sanitize_url_list( mixed $raw ): string {

	$lines   = preg_split( '/\R/u', is_string( $raw ) ? $raw : '' ) ?: [];
	$clean   = [];
	$invalid = [];

	foreach ( $lines as $line ) {

		// sanitize_text_field نه: کدهای %XX نامک فارسی کپی‌شده از نوار آدرس را پاک می‌کند
		$line = trim( wp_strip_all_tags( $line ) );
		if ( '' === $line ) {
			continue;
		}

		$wildcard = str_ends_with( $line, '*' );
		$line     = rtrim( $line, '*' );

		if ( ! preg_match( '#^https?://#i', $line ) ) {
			// دامنه بدون http یا مسیر بدون / ابتدایی
			$line = preg_match( '#^[^/\s]+\.[a-z]{2,}(/|$)#i', $line ) ? 'https://' . $line : '/' . ltrim( $line, '/' );
		}

		$url = esc_url_raw( $line, [ 'https', 'http' ] );

		if ( '' === $url || ( ! str_starts_with( $url, '/' ) && ! wp_parse_url( $url, PHP_URL_HOST ) ) ) {
			$invalid[] = $line;
			continue;
		}

		$clean[] = $url . ( $wildcard ? '*' : '' );
	}

	if ( $invalid ) {
		add_settings_error( HODIMA_SETTINGS_OPTION, 'invalid_social_hide_urls', sprintf( 'این آدرس‌ها در فهرست صفحه‌های بدون شبکه‌های اجتماعی معتبر نبودند و ذخیره نشدند: %s', implode( '، ', $invalid ) ) );
	}

	return implode( "\n", array_values( array_unique( $clean ) ) );
}

/**
 * فهرست دامنه (هر خط یکی): «dl.example.com»، «https://dl.example.com/a.mp4» یا
 * «//cdn.example.com» → «https://dl.example.com» (فقط origin). تکراری حذف؛ نامعتبر
 * رد و به کاربر اطلاع داده می‌شود.
 */
function hodima_settings_sanitize_host_list( string $key, mixed $raw ): string {

	$lines   = preg_split( '/\R/u', is_string( $raw ) ? $raw : '' ) ?: [];
	$clean   = [];
	$invalid = [];

	foreach ( $lines as $line ) {

		$line = trim( wp_strip_all_tags( $line ) );
		if ( '' === $line ) {
			continue;
		}

		$url  = preg_match( '#^https?://#i', $line ) ? $line : 'https://' . ltrim( $line, '/' );
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

		if ( ! preg_match( '/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/', $host ) ) {
			$invalid[] = $line;
			continue;
		}

		$port    = wp_parse_url( $url, PHP_URL_PORT );
		$clean[] = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) ) . '://' . $host . ( $port ? ':' . (int) $port : '' );
	}

	if ( $invalid ) {
		add_settings_error( HODIMA_SETTINGS_OPTION, "invalid_{$key}", sprintf( 'این دامنه‌ها در «%1$s» معتبر نبودند و ذخیره نشدند: %2$s', hodima_settings_field_label( $key ), implode( '، ', $invalid ) ) );
	}

	return implode( "\n", array_values( array_unique( $clean ) ) );
}

/** شماره تلفن: ارقام فارسی/عربی به لاتین؛ فقط ارقام و + ابتدایی. */
function hodima_settings_sanitize_phone( string $key, mixed $raw ): string {

	$raw = is_string( $raw ) ? $raw : '';
	$raw = strtr( $raw, [
		'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
		'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
	] );

	$phone = (string) preg_replace( '/(?!^\+)[^\d]/', '', trim( $raw ) );

	if ( '' !== $phone && ! preg_match( '/^\+?\d{5,15}$/', $phone ) ) {
		add_settings_error( HODIMA_SETTINGS_OPTION, "invalid_{$key}", sprintf( '«%s» معتبر نیست و ذخیره نشد.', hodima_settings_field_label( $key ) ) );
		return '';
	}

	return $phone;
}

function hodima_settings_sanitize_ga( mixed $raw ): string {

	$id = strtoupper( trim( is_string( $raw ) ? $raw : '' ) );

	if ( '' !== $id && ! preg_match( '/^G-[A-Z0-9]{4,16}$/', $id ) ) {
		add_settings_error( HODIMA_SETTINGS_OPTION, 'invalid_ga', 'شناسه Google Analytics باید به شکل G-XXXXXXXXXX باشد و ذخیره نشد.' );
		return '';
	}

	return $id;
}

/* =========================================================================
 * ۳. رندر صفحه تنظیمات
 * ========================================================================= */

add_action( 'admin_enqueue_scripts', static function ( string $hook ): void {

	if ( HODIMA_SETTINGS_HOOK !== $hook ) {
		return;
	}

	wp_enqueue_media();

	hodima_enqueue_asset( 'hodima-theme-settings', 'inc/theme-settings/admin.css' );
	hodima_enqueue_asset( 'hodima-theme-settings', 'inc/theme-settings/admin.js', [ 'media-editor' ], [ 'in_footer' => true, 'strategy' => 'defer' ] );
} );

/**
 * صفحه «تنظیمات قالب هدیما» (منوی سطح اول پیشخوان): منوی کناری گروه‌بندی‌شده + پنل هر تب.
 *
 * تاریخچه: اول همه بخش‌ها زیر هم بودند؛ بعد ده تب در یک ردیف افقی (بی‌ترتیب و
 * در صفحه کوچک‌تر بیرون‌زده)؛ حالا منوی کناری با چهار گروه (ظاهر سایت، صفحه‌ها،
 * ارتباط با مشتری، آمار) و در موبایل یک ردیف لغزنده.
 *   - بدون جاوااسکریپت: هر تب لینک ?tab=… است و سرور پنل همان تب را نشان می‌دهد؛
 *   - با جاوااسکریپت (admin.js): جابه‌جایی فوری، تب فعال بعد از «ذخیره» حفظ
 *     می‌شود (آدرس بازگشت فرم به‌روز می‌شود)، نشانه «ذخیره‌نشده» و Ctrl+S.
 * همه فیلدها در همان یک فرم و یک گزینه (hodima_theme_settings) می‌مانند؛ پنل‌های
 * پنهان هم ارسال می‌شوند، پس ذخیره یک تب مقدار تب‌های دیگر را پاک نمی‌کند.
 */
function hodima_settings_render_page(): void {

	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$settings = hodima_settings();
	$fields   = hodima_settings_fields();
	$sections = hodima_settings_sections();
	$panels   = hodima_settings_panels();
	$version  = (string) wp_get_theme( get_template() )->get( 'Version' );

	$requested = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- فقط انتخاب تب
	$current   = isset( $sections[ $requested ] ) ? $requested : (string) array_key_first( $sections );
	?>
	<div class="wrap hodima-settings">
		<header class="hodima-settings__header">
			<span class="dashicons dashicons-admin-appearance hodima-settings__header-icon" aria-hidden="true"></span>
			<div class="hodima-settings__header-body">
				<?php if ( '' !== $version ) : ?>
					<span class="hodima-settings__badge">قالب هدیما · نسخه <bdi><?php echo esc_html( $version ); ?></bdi></span>
				<?php endif; ?>
				<h1>تنظیمات قالب هدیما</h1>
				<p>ظاهر سایت، صفحه‌ها و راه‌های ارتباطی. هر تغییر بعد از «ذخیره» روی همه صفحه‌های سایت اعمال می‌شود.</p>
			</div>
			<a class="hodima-settings__visit" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">
				<span class="dashicons dashicons-external" aria-hidden="true"></span>
				مشاهده سایت<span class="screen-reader-text"> (در زبانه جدید)</span>
			</a>
		</header>

		<hr class="wp-header-end">

		<?php
		/*
		 * بدون آرگومان: پیام «تنظیمات ذخیره شد» را options.php زیر نامک general
		 * ثبت می‌کند. نسخه قبلی فقط خطاهای همین گزینه را چاپ می‌کرد و بعد از
		 * ذخیره موفق هیچ پیامی دیده نمی‌شد.
		 */
		settings_errors();
		?>

		<div class="hodima-settings__layout">
			<nav class="hodima-settings__nav" aria-label="بخش‌های تنظیمات" data-hodima-nav>
				<?php foreach ( hodima_settings_nav_groups() as $nav_key => $nav_label ) : ?>
					<?php $nav_sections = array_filter( $sections, static fn( array $section ): bool => $section['nav'] === $nav_key ); ?>
					<?php if ( $nav_sections ) : ?>
						<div class="hodima-settings__nav-group">
							<p class="hodima-settings__nav-title" id="hodima-nav-<?php echo esc_attr( $nav_key ); ?>"><?php echo esc_html( $nav_label ); ?></p>
							<ul aria-labelledby="hodima-nav-<?php echo esc_attr( $nav_key ); ?>">
								<?php foreach ( $nav_sections as $section_key => $section ) : ?>
									<li>
										<a
											class="hodima-settings__tab"
											href="<?php echo esc_url( hodima_settings_url( [ 'tab' => $section_key ] ) ); ?>"
											aria-controls="hodima-section-<?php echo esc_attr( $section_key ); ?>"
											data-tab="<?php echo esc_attr( $section_key ); ?>"
											<?php echo $section_key === $current ? 'aria-current="page"' : ''; ?>
										>
											<span class="dashicons <?php echo esc_attr( $section['icon'] ); ?>" aria-hidden="true"></span>
											<span class="hodima-settings__tab-label"><?php echo esc_html( $section['title'] ); ?></span>
											<span class="hodima-settings__tab-dirty" data-hodima-dirty hidden><span class="screen-reader-text">(تغییر ذخیره‌نشده)</span></span>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</nav>

			<form method="post" action="options.php" class="hodima-settings__form" novalidate data-hodima-form>
				<?php settings_fields( 'hodima_theme_settings_group' ); ?>

				<?php foreach ( $sections as $section_key => $section ) : ?>
					<section
						class="hodima-settings__section"
						id="hodima-section-<?php echo esc_attr( $section_key ); ?>"
						data-section="<?php echo esc_attr( $section_key ); ?>"
						aria-labelledby="hodima-section-<?php echo esc_attr( $section_key ); ?>-title"
						<?php echo $section_key === $current ? '' : 'hidden'; ?>
					>
						<header class="hodima-settings__section-head">
							<span class="dashicons <?php echo esc_attr( $section['icon'] ); ?>" aria-hidden="true"></span>
							<div>
								<h2 id="hodima-section-<?php echo esc_attr( $section_key ); ?>-title" tabindex="-1"><?php echo esc_html( $section['title'] ); ?></h2>
								<p><?php echo esc_html( $section['description'] ); ?></p>
							</div>
						</header>

						<div class="hodima-settings__panels">
							<?php
							// تب «شبکه‌های اجتماعی»: فهرست پویا (گزینه جدا، همین فرم) بالای قاب «نمایش در صفحه‌ها»
							if ( 'social' === $section_key && function_exists( 'hodima_social_admin_render' ) ) {
								hodima_social_admin_render();
							}

							foreach ( $panels as $panel_key => $panel ) {
								if ( $panel['section'] === $section_key ) {
									hodima_settings_render_panel(
										$panel_key,
										$panel,
										array_filter( $fields, static fn( array $field ): bool => ( $field['panel'] ?? '' ) === $panel_key ),
										$settings
									);
								}
							}

							// تب «صفحه اصلی»: فهرست بخش‌ها (گزینه جدا، همین فرم)
							if ( 'home' === $section_key && function_exists( 'hodima_home_admin_render' ) ) {
								hodima_home_admin_render();
							}
							?>
						</div>
					</section>
				<?php endforeach; ?>

				<footer class="hodima-settings__actions">
					<p class="hodima-settings__status" data-hodima-status aria-live="polite">
						<span class="hodima-settings__status-dirty">تغییرهای ذخیره‌نشده دارید</span>
						<span class="hodima-settings__status-hint">میان‌بر ذخیره: <kbd dir="ltr">Ctrl + S</kbd></span>
					</p>
					<?php submit_button( 'ذخیره تنظیمات', 'primary hodima-settings__save', 'submit', false ); ?>
				</footer>
			</form>
		</div>
		<?php hodima_settings_backup_form_if_any(); ?>
	</div>
	<?php
}

/** فرم بازگردانی پشتیبان (inc/extras.php) بیرون از فرم اصلی. */
function hodima_settings_backup_form_if_any(): void {
	if ( function_exists( 'hodima_settings_backup_form' ) ) {
		hodima_settings_backup_form();
	}
}

/**
 * یک قاب: سرتیتر (آیکون، عنوان، توضیح)، فیلدهای آزاد در شبکه، بعد زیرگروه‌ها
 * (کارت‌های نماد اعتماد یا ردیف‌های شبکه‌ها).
 *
 * @param array<string, mixed>                $panel
 * @param array<string, array<string, mixed>> $fields فیلدهای همین قاب، به ترتیب تعریف
 * @param array<string, mixed>                $settings
 */
function hodima_settings_render_panel( string $key, array $panel, array $fields, array $settings ): void {

	$layout  = (string) ( $panel['layout'] ?? 'grid' );
	$groups  = hodima_settings_groups();
	$loose   = array_filter( $fields, static fn( array $field ): bool => ! isset( $field['group'] ) );
	$grouped = [];

	foreach ( $fields as $field_key => $field ) {
		if ( isset( $field['group'] ) ) {
			$grouped[ $field['group'] ][ $field_key ] = $field;
		}
	}

	$collapse = ! empty( $panel['collapsible'] ); // قاب جمع‌شونده (<details>، پیش‌فرض بسته)؛ مثلا پیش‌نمایش تایپوگرافی
	$classes  = 'hodima-panel hodima-panel--' . $layout . ' hodima-panel-' . $key . ( ! empty( $panel['half'] ) ? ' hodima-panel--half' : '' ) . ( $collapse ? ' hodima-panel--collapsible' : '' ) . ( ! empty( $panel['headings'] ) ? ' hodima-panel--headings' : '' );
	$title    = 'hodima-panel-' . $key . '-title';
	?>
	<?php if ( $collapse ) : ?>
		<?php
		// باز بودن اجباری (مثلا «فونت آپلودی» وقتی همان فونت انتخاب شده) و بازشدن با تغییر فیلدهای دیگر (admin.js)
		$force_open = ! empty( $panel['force_open'] ) && is_callable( $panel['force_open'] ) && (bool) call_user_func( $panel['force_open'] );
		?>
		<details class="<?php echo esc_attr( $classes ); ?>" data-hodima-collapsible="<?php echo esc_attr( $key ); ?>"<?php echo $force_open ? ' open data-hodima-keep-open' : ''; ?><?php echo ! empty( $panel['open_on'] ) ? ' data-hodima-open-on="' . esc_attr( implode( ' ', (array) $panel['open_on'] ) ) . '"' : ''; ?>>
			<summary class="hodima-panel__summary">
				<?php hodima_settings_panel_head( $title, $panel['title'], $panel['help'] ?? '', $panel['icon'] ?? '', '<span class="hodima-panel__chevron dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>' ); ?>
			</summary>
	<?php else : ?>
	<section class="<?php echo esc_attr( $classes ); ?>" aria-labelledby="<?php echo esc_attr( $title ); ?>">
		<?php hodima_settings_panel_head( $title, $panel['title'], $panel['help'] ?? '', $panel['icon'] ?? '' ); ?>
	<?php endif; ?>

		<div class="hodima-panel__body">
			<?php if ( 'swatches' === $layout ) : ?>
				<?php hodima_settings_palette_preview( $settings ); ?>
			<?php elseif ( 'typepreview' === $layout ) : ?>
				<?php hodima_typography_preview(); ?>
			<?php elseif ( 'lookpreview' === $layout ) : ?>
				<?php hodima_appearance_preview(); ?>
			<?php elseif ( 'backup' === $layout && function_exists( 'hodima_settings_backup_panel' ) ) : ?>
				<?php hodima_settings_backup_panel(); ?>
			<?php endif; ?>

			<?php if ( $loose && empty( $panel['headings'] ) ) : ?>
				<div class="hodima-panel__fields">
					<?php foreach ( $loose as $field_key => $field ) : ?>
						<?php hodima_settings_render_field( $field_key, $field, $settings[ $field_key ] ); ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $grouped ) : ?>
				<?php if ( ! empty( $panel['headings'] ) ) : ?>
					<?php hodima_settings_render_headings( $panel, $grouped, $groups, $settings, $loose ); ?>
				<?php elseif ( 'tiles' === $layout ) : ?>
					<?php hodima_settings_render_tiles( $panel, $grouped, $groups, $settings ); ?>
				<?php else : ?>
					<?php if ( ! empty( $panel['columns'] ) ) : ?>
						<?php hodima_settings_render_columns( (array) $panel['columns'] ); ?>
					<?php endif; ?>
					<?php hodima_settings_render_items( $grouped, $groups, $settings ); ?>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	<?php echo $collapse ? '</details>' : '</section>'; // phpcs:ignore WordPress.Security.EscapeOutput -- برچسب ثابت ?>
	<?php
}

/**
 * سرستون‌های جدول «ردیف‌ها» (فقط تزئینی؛ برچسب فیلدها برای صفحه‌خوان در خود ردیف است).
 *
 * @param array<int, string> $columns
 */
function hodima_settings_render_columns( array $columns ): void {
	?>
	<div class="hodima-panel__columns" aria-hidden="true">
		<?php foreach ( $columns as $column ) : ?>
			<span><?php echo esc_html( (string) $column ); ?></span>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * ردیف‌های یک قاب (هر زیرگروه یک fieldset: نماد اعتماد، شبکه، تیتر).
 *
 * @param array<string, array<string, array<string, mixed>>> $grouped
 * @param array<string, array<string, mixed>>               $groups
 * @param array<string, mixed>                              $settings
 */
function hodima_settings_render_items( array $grouped, array $groups, array $settings, string $css_class = 'hodima-panel__items' ): void {
	?>
	<div class="<?php echo esc_attr( $css_class ); ?>">
		<?php foreach ( $grouped as $group => $group_fields ) : ?>
			<fieldset class="hodima-group" data-group="<?php echo esc_attr( $group ); ?>">
				<legend class="hodima-group__title"><?php echo esc_html( $groups[ $group ]['title'] ?? $group ); ?></legend>
				<div class="hodima-group__fields">
					<?php foreach ( $group_fields as $field_key => $field ) : ?>
						<?php hodima_settings_render_field( $field_key, $field, $settings[ $field_key ] ); ?>
					<?php endforeach; ?>
				</div>
			</fieldset>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * قاب «تیترها» (3.0.9): اندازه‌ها (فقط همین دو ستون برای هر تیتر فرق دارند) در جدول کوتاه،
 * وزن/فاصله خطوط/رنگ یک بار برای همه (کنترل کمکی بی name که مقدار شش فیلد واقعی را
 * هم‌زمان عوض می‌کند، admin.js) و «تنظیم جدا برای هر تیتر» جمع‌شونده. فیلدهای واقعی
 * همان کلیدهای قبلی‌اند و همیشه در فرم هستند (جمع‌شده هم ارسال می‌شوند).
 *
 * @param array<string, mixed>                               $panel
 * @param array<string, array<string, array<string, mixed>>> $grouped
 * @param array<string, array<string, mixed>>               $groups
 * @param array<string, mixed>                              $settings
 * @param array<string, array<string, mixed>>               $loose فیلدهای آزاد قاب (فونت تیترها)؛ اول کارت «همه تیترها»
 */
function hodima_settings_render_headings( array $panel, array $grouped, array $groups, array $settings, array $loose = [] ): void {

	$sizes  = [];
	$others = [];
	foreach ( $grouped as $group => $group_fields ) {
		foreach ( $group_fields as $field_key => $field ) {
			if ( str_contains( $field_key, '_size' ) ) {
				$sizes[ $group ][ $field_key ] = $field;
			} else {
				$others[ $group ][ $field_key ] = $field;
			}
		}
	}

	$shared = hodima_typography_shared_heading_fields( $settings );
	?>
	<?php if ( $shared['fields'] || $loose ) : ?>
		<div class="hodima-headings-all">
			<h4 class="hodima-headings-all__title">همه تیترها</h4>
			<p class="hodima-field__help">فونت، وزن، فاصله خطوط و رنگ یکسان برای H1 تا H6. اندازه هر تیتر در جدول کنار آن است.</p>
			<div class="hodima-panel__fields hodima-headings-all__fields">
				<?php foreach ( $loose as $field_key => $field ) : ?>
					<?php hodima_settings_render_field( $field_key, $field, $settings[ $field_key ] ); ?>
				<?php endforeach; ?>
				<?php foreach ( $shared['fields'] as $field_key => $item ) : ?>
					<?php hodima_settings_render_field( $field_key, $item['field'], $item['value'] ); ?>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endif; ?>

	<div class="hodima-headings-sizes">
		<?php hodima_settings_render_columns( (array) ( $panel['columns'] ?? [] ) ); ?>
		<?php hodima_settings_render_items( $sizes, $groups, $settings ); ?>
	</div>

	<details class="hodima-more hodima-headings-more" <?php echo $shared['differs'] ? 'open' : ''; ?>>
		<summary class="hodima-more__summary">تنظیم جدا برای هر تیتر<?php echo $shared['differs'] ? ' (مقدارهای فعلی یکسان نیستند)' : ''; ?></summary>
		<?php hodima_settings_render_columns( (array) ( $panel['columns_more'] ?? [] ) ); ?>
		<?php hodima_settings_render_items( $others, $groups, $settings ); ?>
	</details>
	<?php
}

/**
 * قاب «فونت آپلودی»: کاشی هر وزن؛ وزن‌های اصلی دیده می‌شوند و بقیه زیر «وزن‌های بیشتر»
 * (اگر یکی‌شان فایل دارد خودکار باز است).
 *
 * @param array<string, mixed>                               $panel
 * @param array<string, array<string, array<string, mixed>>> $grouped
 * @param array<string, array<string, mixed>>               $groups
 * @param array<string, mixed>                              $settings
 */
function hodima_settings_render_tiles( array $panel, array $grouped, array $groups, array $settings ): void {

	$primary = (array) ( $panel['primary'] ?? [] );
	$main    = array_intersect_key( $grouped, array_flip( $primary ) );
	$more    = array_diff_key( $grouped, $main );
	$filled  = false;

	foreach ( $more as $group_fields ) {
		foreach ( array_keys( $group_fields ) as $field_key ) {
			$filled = $filled || ! empty( $settings[ $field_key ] );
		}
	}

	hodima_settings_render_items( $main, $groups, $settings, 'hodima-panel__items hodima-panel__items--tiles' );
	?>
	<?php if ( $more ) : ?>
		<details class="hodima-more" <?php echo $filled ? 'open' : ''; ?>>
			<summary class="hodima-more__summary">وزن‌های بیشتر (نازک، متوسط، نیم‌ضخیم، خیلی ضخیم، سیاه)</summary>
			<?php hodima_settings_render_items( $more, $groups, $settings, 'hodima-panel__items hodima-panel__items--tiles' ); ?>
		</details>
	<?php endif; ?>
	<?php
}


/**
 * راهنمای بلند ← یک جمله دیدنی + بقیه در آیکون ؟: جمله اول (تا اولین نقطه/؟/! با فاصله بعدش)
 * همیشه دیده می‌شود؛ بقیه به حباب می‌رود. متن کوتاه (تا ۹۰ حرف) یا بدون جمله دوم دست نمی‌خورد.
 *
 * @return array{0: string, 1: string} [ دیدنی، حباب ]
 */
function hodima_settings_split_help( string $help ): array {

	if ( mb_strlen( $help ) <= 90 || ! preg_match( '/^(.{20,}?[.؟!])\s+(.+)$/us', $help, $match ) ) {
		return [ $help, '' ];
	}

	return [ $match[1], $match[2] ];
}

/**
 * آیکون ؟ با حباب راهنما (admin.js: هاور، فوکوس، کلیک/لمس، Esc). متن راهنما در HTML می‌ماند
 * و کنترل با aria-describedby به آن وصل است؛ پس صفحه‌خوان هم می‌خواند.
 */
function hodima_settings_tip_html( string $text, string $id, string $label ): string {

	return '<span class="hodima-tip">'
		. '<button type="button" class="hodima-tip__button" aria-expanded="false" aria-label="' . esc_attr( 'راهنما: ' . $label ) . '"><span class="dashicons dashicons-editor-help hodima-tip__icon" aria-hidden="true"></span></button>'
		. '<span class="hodima-tip__bubble" role="tooltip" id="' . esc_attr( $id ) . '">' . esc_html( $text ) . '</span>'
		. '</span>';
}

/**
 * برچسب کادر؛ اگر راهنما دارد با آیکون ؟ کنارش در یک ردیف (3.1.1).
 *
 * @param string $label_html برچسب آماده (label یا span؛ escape شده توسط فراخواننده)
 */
function hodima_settings_field_head( string $label_html, string $help, string $help_id, string $label ): void {

	if ( '' === $help ) {
		echo $label_html; // phpcs:ignore WordPress.Security.EscapeOutput -- فراخواننده escape کرده
		return;
	}

	echo '<span class="hodima-field__head">' . $label_html . hodima_settings_tip_html( $help, $help_id, $label ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput -- برچسب و حباب escape شده‌اند
}

/** سرتیتر قاب (مشترک با قاب «بخش‌های صفحه اصلی» در home-layout-admin.php). */
function hodima_settings_panel_head( string $id, string $title, string $help = '', string $icon = '', string $extra = '' ): void {
	?>
	<header class="hodima-panel__head">
		<?php if ( '' !== $icon ) : ?>
			<span class="hodima-panel__icon dashicons <?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
		<?php endif; ?>
		<div class="hodima-panel__heading">
			<h3 class="hodima-panel__title" id="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $title ); ?></h3>
			<?php if ( '' !== $help ) : ?>
				<?php [ $help_first, $help_rest ] = hodima_settings_split_help( $help ); ?>
				<p class="hodima-panel__help"><?php echo esc_html( $help_first ); ?><?php echo '' !== $help_rest ? ' ' . hodima_settings_tip_html( $help_rest, $id . '-help', $title ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- hodima_settings_tip_html خروجی را escape کرده ?></p>
			<?php endif; ?>
		</div>
		<?php echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput -- نشانه‌گذاری ثابت فراخواننده ?>
	</header>
	<?php
}

/**
 * نمونه کوچک سایت با پالت فعلی (تب «برند و رنگ‌ها»). admin.js با تغییر هر رنگ
 * متغیرهای همین ظرف را عوض می‌کند تا نتیجه پیش از ذخیره دیده شود.
 * @param array<string, mixed> $settings
 */
function hodima_settings_palette_preview( array $settings ): void {

	$vars = '';
	foreach ( [ 'primary', 'secondary', 'third', 'accent', 'accent_light' ] as $name ) {
		$value = sanitize_hex_color( (string) ( $settings[ 'color_' . $name ] ?? '' ) );
		if ( $value ) {
			$vars .= '--pv-' . str_replace( '_', '-', $name ) . ':' . $value . ';';
		}
	}
	?>
	<div class="hodima-palette-preview" style="<?php echo esc_attr( $vars ); ?>" data-hodima-palette-preview aria-hidden="true">
		<div class="hodima-palette-preview__header">
			<span class="hodima-palette-preview__logo"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			<span class="hodima-palette-preview__menu"><span></span><span></span><span></span></span>
			<span class="hodima-palette-preview__support">پشتیبانی</span>
		</div>
		<div class="hodima-palette-preview__body">
			<span class="hodima-palette-preview__chip">دسته‌بندی</span>
			<strong class="hodima-palette-preview__title">عنوان نمونه محصول</strong>
			<span class="hodima-palette-preview__line"></span>
			<span class="hodima-palette-preview__buttons">
				<span class="hodima-palette-preview__button">افزودن به سبد</span>
				<span class="hodima-palette-preview__button hodima-palette-preview__button--accent">خرید عمده</span>
			</span>
		</div>
	</div>
	<?php
}

/**
 * @param array{panel:string, type:string, label:string, default:mixed, group?:string, help?:string, placeholder?:string, wide?:bool, preview?:string, options?:array<string, string>, min?:int, max?:int, custom_key?:string, embedded?:bool} $field
 */
function hodima_settings_render_field( string $key, array $field, mixed $value ): void {

	// رنگ دلخواه (embedded): داخل کارت فهرست مالکش (custom_key) چاپ می‌شود، نه جدا
	if ( ! empty( $field['embedded'] ) ) {
		return;
	}

	$id        = 'hodima-setting-' . $key;
	$name      = empty( $field['unsaved'] ) ? HODIMA_SETTINGS_OPTION . '[' . $key . ']' : ''; // unsaved: کنترل کمکی پیشخوان («همه تیترها»)، ارسال نمی‌شود
	$help      = $field['help'] ?? '';
	$help_id   = $id . '-help';
	$described = '' !== $help ? ' aria-describedby="' . esc_attr( $help_id ) . '"' : '';
	$type      = hodima_setting_type( $field );
	// راهنمای کادر ← آیکون ؟ کنار برچسب (3.1.1). می‌ماند: کلید (توضیح جزو کاشی است)، فیلد زیرگروه (ردیف جدول) و فیلد با help_visible (هشدار/شرط مهم)
	$tip       = '' !== $help && ! isset( $field['group'] ) && empty( $field['help_visible'] ) && Hodima_Setting_Type::Toggle !== $type;
	$wide      = ( $field['wide'] ?? $type->is_wide() ) && ! isset( $field['group'] ) ? ' hodima-field--wide' : '';
	?>
	<div class="hodima-field hodima-field--<?php echo esc_attr( $field['type'] . $wide ); ?>">
		<?php if ( Hodima_Setting_Type::Toggle === $type ) : ?>
			<?php /* کاشی کلید: کل کادر قابل کلیک؛ توضیح داخل همان کادر */ ?>
			<label class="hodima-toggle" for="<?php echo esc_attr( $id ); ?>">
				<input type="checkbox" role="switch" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( (bool) $value ); ?><?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>>
				<span class="hodima-toggle__text">
					<span class="hodima-toggle__label"><?php echo esc_html( $field['label'] ); ?></span>
					<?php if ( '' !== $help ) : ?>
						<span class="hodima-field__help" id="<?php echo esc_attr( $help_id ); ?>"><?php echo esc_html( $help ); ?></span>
					<?php endif; ?>
				</span>
				<span class="hodima-toggle__track" aria-hidden="true"></span>
			</label>
			<?php $help = ''; // توضیح بالاتر چاپ شد ?>

		<?php elseif ( Hodima_Setting_Type::Color === $type ) : ?>
			<?php
			/*
			 * کنترل رنگ یکدست (3.0.1): برچسب بالا، [مربع رنگ | کد رنگ] هم‌ارتفاع بقیه
			 * کادرها، توضیح و «بازگشت به پیش‌فرض» زیر آن — همان شکل «انتخاب از پالت»
			 * (.hodima-color). تا 3.0.0 کارت با بلوک رنگ تمام‌عرض بود.
			 * کد رنگ بی name است (مقدار با input رنگ ارسال می‌شود؛ admin.js همگام می‌کند).
			 */
			$default = strtolower( (string) $field['default'] );
			?>
			<?php hodima_settings_field_head( '<label class="hodima-field__label" for="' . esc_attr( $id ) . '-hex">' . esc_html( $field['label'] ) . '</label>', $tip ? $help : '', $help_id, (string) $field['label'] ); ?>
			<span class="hodima-color">
				<input
					type="color"
					class="hodima-color__swatch"
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					value="<?php echo esc_attr( (string) $value ); ?>"
					data-hodima-color="<?php echo esc_attr( str_replace( [ 'color_', '_' ], [ '', '-' ], $key ) ); ?>"
					aria-label="<?php echo esc_attr( sprintf( 'انتخاب %s از جعبه رنگ', $field['label'] ) ); ?>"
				>
				<input
					type="text"
					class="hodima-color__hex"
					id="<?php echo esc_attr( $id ); ?>-hex"
					value="<?php echo esc_attr( (string) $value ); ?>"
					dir="ltr"
					maxlength="7"
					spellcheck="false"
					autocomplete="off"
					pattern="#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})"
					placeholder="#25316a"
					data-hodima-color-value
					<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>
				>
			</span>
			<?php if ( '' !== $help && ! $tip ) : ?>
				<p class="hodima-field__help" id="<?php echo esc_attr( $help_id ); ?>"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
			<button type="button" class="hodima-color__reset" title="بازگشت به پیش‌فرض" data-hodima-color-reset="<?php echo esc_attr( $default ); ?>" <?php echo strtolower( (string) $value ) === $default ? 'hidden' : ''; ?>>
				<span class="dashicons dashicons-undo" aria-hidden="true"></span>
				بازگشت به پیش‌فرض <code dir="ltr"><?php echo esc_html( $default ); ?></code>
			</button>
			<?php $help = ''; // توضیح بالاتر چاپ شد ?>

		<?php elseif ( Hodima_Setting_Type::Image === $type ) : ?>
			<?php
			$image_id = (int) $value;
			$header   = 'header' === ( $field['preview'] ?? '' );
			$inverted = $header && hodima_setting( 'logo_invert' );
			?>
			<?php hodima_settings_field_head( '<span class="hodima-field__label" id="' . esc_attr( $id ) . '-label">' . esc_html( $field['label'] ) . '</span>', $tip ? $help : '', $help_id, (string) $field['label'] ); ?>
			<div class="hodima-media" data-hodima-media>
				<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $image_id ); ?>" data-hodima-media-input>
				<figure
					class="hodima-media__preview<?php echo $header ? ' hodima-media__preview--header' : ''; ?><?php echo $inverted ? ' is-inverted' : ''; ?><?php echo $image_id ? '' : ' is-empty'; ?>"
					data-hodima-media-preview
					<?php echo $header ? 'data-hodima-invert-source="hodima-setting-logo_invert"' : ''; ?>
				>
					<?php echo $image_id ? wp_get_attachment_image( $image_id, 'medium', false, [ 'alt' => '' ] ) : ''; ?>
					<span class="hodima-media__empty" aria-hidden="true"><span class="dashicons dashicons-format-image"></span><span class="hodima-media__empty-text">بدون تصویر</span></span>
				</figure>
				<div class="hodima-media__buttons">
					<button type="button" class="button" data-hodima-media-select aria-describedby="<?php echo esc_attr( $id ); ?>-label" data-title="<?php echo esc_attr( $field['label'] ); ?>"><?php echo $image_id ? 'تغییر تصویر' : 'انتخاب تصویر'; ?></button>
					<button type="button" class="button-link hodima-media__remove" data-hodima-media-remove aria-describedby="<?php echo esc_attr( $id ); ?>-label" <?php echo $image_id ? '' : 'hidden'; ?>>حذف</button>
				</div>
			</div>

		<?php elseif ( Hodima_Setting_Type::Font === $type ) : ?>
			<?php
			$font_id   = (int) $value;
			$font_name = $font_id ? wp_basename( (string) get_attached_file( $font_id ) ) : '';
			?>
			<span class="hodima-field__label screen-reader-text" id="<?php echo esc_attr( $id ); ?>-label"><?php echo esc_html( $field['label'] ); ?></span>
			<div class="hodima-media hodima-media--file" data-hodima-media data-hodima-media-kind="font">
				<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $font_id ); ?>" data-hodima-media-input>
				<span class="hodima-media__file<?php echo $font_id ? '' : ' is-empty'; ?>" data-hodima-media-preview>
					<span class="dashicons dashicons-media-default" aria-hidden="true"></span>
					<bdi dir="ltr" data-hodima-media-name><?php echo esc_html( $font_name ); ?></bdi>
					<span class="hodima-media__empty-text">بدون فایل</span>
				</span>
				<div class="hodima-media__buttons">
					<button type="button" class="button" data-hodima-media-select aria-describedby="<?php echo esc_attr( $id ); ?>-label" data-title="<?php echo esc_attr( $field['label'] ); ?>"><?php echo $font_id ? 'تغییر فایل' : 'انتخاب فایل'; ?></button>
					<button type="button" class="button-link hodima-media__remove" data-hodima-media-remove aria-describedby="<?php echo esc_attr( $id ); ?>-label" <?php echo $font_id ? '' : 'hidden'; ?>>حذف</button>
				</div>
				<?php if ( preg_match( '/^font_custom_(\d+)$/', $key, $hodima_w ) ) : ?>
					<?php // نمونه همین وزن با فونت آپلودی (پیش از ذخیره هم: admin.js همان خانواده را با FontFace اضافه می‌کند) ?>
					<span class="hodima-font-sample" data-hodima-font-sample style="<?php echo esc_attr( sprintf( "font-family: '%s', Tahoma, sans-serif; font-weight: %d", hodima_typography_custom_family(), (int) $hodima_w[1] ) ); ?>" <?php echo $font_id ? '' : 'hidden'; ?>>نمونه متن فارسی ۱۲۳ Abc</span>
				<?php endif; ?>
			</div>

		<?php else : ?>
			<?php hodima_settings_field_head( '<label class="hodima-field__label" for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . '</label>', $tip ? $help : '', $help_id, (string) $field['label'] ); ?>
			<?php if ( Hodima_Setting_Type::Textarea === $type ) : ?>
				<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="4"<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>><?php echo esc_textarea( (string) $value ); ?></textarea>
			<?php elseif ( Hodima_Setting_Type::Number === $type ) : ?>
				<input
					type="number"
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					value="<?php echo esc_attr( hodima_number_text( is_numeric( $value ) ? 0 + $value : 0 ) ); ?>"
					min="<?php echo esc_attr( (string) ( $field['min'] ?? 0 ) ); ?>"
					max="<?php echo esc_attr( (string) ( $field['max'] ?? '' ) ); ?>"
					<?php if ( isset( $field['step'] ) ) : ?>
						step="<?php echo esc_attr( (string) $field['step'] ); ?>"
						inputmode="decimal"
					<?php else : ?>
						inputmode="numeric"
					<?php endif; ?>
					<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>
				>
			<?php elseif ( Hodima_Setting_Type::Select === $type ) : ?>
				<?php
				$hodima_swatch = ! empty( $field['swatch'] );
				$custom_key    = (string) ( $field['custom_key'] ?? '' );
				$custom_on     = '' !== $custom_key && 'custom' === (string) $value;
				$custom_val    = '' !== $custom_key ? (string) hodima_setting( $custom_key ) : '';
				$custom_def    = '' !== $custom_key ? strtolower( (string) ( hodima_settings_fields()[ $custom_key ]['default'] ?? '' ) ) : '';
				// انتخاب از پالت: همان کنترل رنگ (.hodima-color)، مربع رنگ کنار فهرست (admin.js با پالت زنده)
				?>
				<?php if ( $hodima_swatch ) : ?>
					<?php
					// «دلخواه»: مربع رنگ همین کارت انتخاب‌گر می‌شود و کد رنگ زیر فهرست می‌آید (3.2.0)؛ با فهرست روی رنگ پالت پنهان‌اند (admin.js)
					?>
					<span class="hodima-color">
						<span class="hodima-color__swatch" data-hodima-color-dot style="background: <?php echo esc_attr( hodima_settings_palette_hex( (string) $value ) ); ?>" aria-hidden="true"<?php echo $custom_on ? ' hidden' : ''; ?>></span>
					<?php if ( '' !== $custom_key ) : ?>
						<input
							type="color"
							class="hodima-color__swatch"
							id="hodima-setting-<?php echo esc_attr( $custom_key ); ?>"
							name="<?php echo esc_attr( HODIMA_SETTINGS_OPTION . '[' . $custom_key . ']' ); ?>"
							value="<?php echo esc_attr( $custom_val ); ?>"
							data-hodima-color="<?php echo esc_attr( str_replace( '_', '-', $custom_key ) ); ?>"
							data-hodima-when-custom
							aria-label="<?php echo esc_attr( sprintf( 'انتخاب %s از جعبه رنگ', $field['label'] ) ); ?>"
							<?php echo $custom_on ? '' : 'hidden'; ?>
						>
					<?php endif; ?>
				<?php endif; ?>
				<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>"<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>>
					<?php foreach ( (array) ( $field['options'] ?? [] ) as $option => $label ) : ?>
						<option value="<?php echo esc_attr( (string) $option ); ?>" <?php selected( (string) $value, (string) $option ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php if ( $hodima_swatch && '' !== $custom_key ) : ?>
					<input type="text" class="hodima-color__hex" id="hodima-setting-<?php echo esc_attr( $custom_key ); ?>-hex" value="<?php echo esc_attr( $custom_val ); ?>" dir="ltr" maxlength="7" spellcheck="false" autocomplete="off" placeholder="#25316a" aria-label="<?php echo esc_attr( sprintf( 'کد %s', $field['label'] ) ); ?>" data-hodima-color-value data-hodima-when-custom<?php echo $custom_on ? '' : ' hidden'; ?>>
					<button type="button" class="hodima-color__reset" title="بازگشت به پیش‌فرض" data-hodima-color-reset="<?php echo esc_attr( $custom_def ); ?>" data-hodima-when-custom <?php echo $custom_on && strtolower( $custom_val ) !== $custom_def ? '' : 'hidden'; ?>>
						<span class="dashicons dashicons-undo" aria-hidden="true"></span>
						بازگشت به پیش‌فرض <code dir="ltr"><?php echo esc_html( $custom_def ); ?></code>
					</button>
				<?php endif; ?>
				<?php if ( $hodima_swatch ) : ?>
					</span>
				<?php endif; ?>
			<?php elseif ( Hodima_Setting_Type::Code === $type ) : ?>
				<textarea
					class="hodima-code"
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					rows="6"
					dir="ltr"
					spellcheck="false"
					autocomplete="off"
					<?php echo isset( $field['placeholder'] ) ? 'placeholder="' . esc_attr( $field['placeholder'] ) . '"' : ''; ?>
					<?php echo current_user_can( 'unfiltered_html' ) ? '' : 'readonly'; ?>
					<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>
				><?php echo esc_textarea( (string) $value ); ?></textarea>
			<?php elseif ( $type->is_list() ) : ?>
				<textarea
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					rows="<?php echo Hodima_Setting_Type::HostList === $type ? '3' : '5'; // یک یا دو دامنه؛ فهرست آدرس بلندتر ?>"
					dir="ltr"
					spellcheck="false"
					autocomplete="off"
					<?php echo isset( $field['placeholder'] ) ? 'placeholder="' . esc_attr( $field['placeholder'] ) . '"' : ''; ?>
					<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>
				><?php echo esc_textarea( (string) $value ); ?></textarea>
			<?php else : ?>
				<input
					type="<?php echo esc_attr( $type->input_type() ); ?>"
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					value="<?php echo esc_attr( (string) $value ); ?>"
					<?php echo isset( $field['placeholder'] ) ? 'placeholder="' . esc_attr( $field['placeholder'] ) . '"' : ''; ?>
					<?php echo $type->is_ltr() ? 'dir="ltr"' : ''; ?>
					<?php echo Hodima_Setting_Type::Ga === $type ? 'pattern="G-[A-Za-z0-9]{4,16}" autocomplete="off" spellcheck="false"' : ''; ?>
					<?php echo $described; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above ?>
				>
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( '' !== $help && ! $tip ) : ?>
			<p class="hodima-field__help" id="<?php echo esc_attr( $help_id ); ?>"><?php echo esc_html( $help ); ?></p>
		<?php endif; ?>

		<?php if ( Hodima_Setting_Type::HostList === $type ) : // بعد از توضیح، مثل بقیه فیلدها (کنترل ← توضیح ← افزوده‌ها) ?>
			<?php hodima_settings_render_host_suggestions( $id, (string) $value ); ?>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * «دامنه‌های پیدا شده» زیر کادر دامنه ویدئو: دامنه‌هایی که ویدیو، کاور و
 * پادکست‌های همین سایت واقعا از آن‌ها پخش می‌شوند (Hodima Media، پرتکرار
 * اول) با دکمه «افزودن» (admin.js). دامنه عوض شود یا قالب روی سایت دیگری
 * نصب شود، فهرست از رسانه‌های همان سایت ساخته می‌شود؛ هیچ دامنه‌ای در کد نیست.
 */
function hodima_settings_render_host_suggestions( string $target_id, string $value ): void {

	if ( ! function_exists( 'hodima_media_external_hosts' ) ) {
		echo '<p class="hodima-hosts__note">برای پیدا کردن خودکار دامنه‌ها، افزونه Hodima Media لازم است.</p>';
		return;
	}

	$hosts   = array_slice( hodima_media_external_hosts(), 0, 12, true );
	$entered = array_filter( array_map( static fn( string $line ): string => strtolower( trim( $line ) ), preg_split( '/\R/u', $value ) ?: [] ) );
	?>
	<div class="hodima-hosts" data-hodima-hosts="<?php echo esc_attr( $target_id ); ?>">
		<p class="hodima-hosts__title">دامنه‌های پیدا شده در ویدیو و پادکست‌های سایت</p>
		<?php if ( ! $hosts ) : ?>
			<p class="hodima-hosts__note">هنوز ویدیو یا پادکستی از دامنه دیگری در سایت ثبت نشده است.</p>
		<?php else : ?>
			<ul class="hodima-hosts__list">
				<?php foreach ( $hosts as $origin => $count ) : ?>
					<?php $hodima_added = in_array( strtolower( $origin ), $entered, true ); ?>
					<li>
						<button
							type="button"
							class="button button-small hodima-hosts__add"
							data-hodima-host="<?php echo esc_attr( $origin ); ?>"
							aria-label="<?php echo esc_attr( sprintf( 'افزودن %s', $origin ) ); ?>"
							<?php disabled( $hodima_added ); ?>
						>
							<span class="dashicons <?php echo $hodima_added ? 'dashicons-yes' : 'dashicons-plus-alt2'; ?>" aria-hidden="true"></span>
							<bdi dir="ltr"><?php echo esc_html( (string) preg_replace( '#^https?://#', '', $origin ) ); ?></bdi>
							<span class="hodima-hosts__count"><?php echo esc_html( sprintf( '%s رسانه', number_format_i18n( $count ) ) ); ?></span>
						</button>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
}

/* =========================================================================
 * ۴. توابع نمایشی برای قالب
 * ========================================================================= */

/** HTML لوگوی هدر: تصویر تنظیمات ← لوگوی سفارشی وردپرس ← نام سایت. */
function hodima_logo_html(): string {

	$site_name = get_bloginfo( 'name' );
	$logo_id   = (int) hodima_setting( 'logo_id' );

	if ( ! $logo_id ) {
		$logo_id = (int) get_theme_mod( 'custom_logo' );
	}

	if ( $logo_id && wp_attachment_is_image( $logo_id ) ) {
		return (string) wp_get_attachment_image( $logo_id, 'medium', false, [
			'alt'           => $site_name,
			'loading'       => 'eager',
			'fetchpriority' => 'high',
			'decoding'      => 'async',
			'class'         => 'header__logo-img',
		] );
	}

	return '<span class="header__logo-text">' . esc_html( $site_name ) . '</span>';
}

/**
 * کانال‌های تماس پیکربندی‌شده برای پنجره پشتیبانی، به ترتیب enum
 * Hodima_Contact_Channel (تماس، واتس‌اپ، روبیکا، تلگرام). کانال بدون مقدار رد می‌شود.
 *
 * @return list<Hodima_Contact_Link>
 */
function hodima_contact_channels(): array {

	$links = [];

	foreach ( Hodima_Contact_Channel::cases() as $channel ) {
		$value = (string) hodima_setting( $channel->setting() );
		if ( '' !== $value ) {
			$links[] = new Hodima_Contact_Link( $channel, $value );
		}
	}

	return $links;
}

/**
 * یک ردیف شبکه ← شکل استاندارد (بی‌آدرس = null). آدرس بدون http(s) با https:// کامل می‌شود؛
 * نام خالی از دامنه آدرس ساخته می‌شود.
 *
 * @param array<string, mixed> $row
 * @return array{id:string, label:string, url:string, icon_id:int}|null
 */
function hodima_social_clean_item( array $row ): ?array {

	$url = trim( (string) ( $row['url'] ?? '' ) );
	if ( '' !== $url && ! preg_match( '#^[a-z][a-z0-9+.-]*:#i', $url ) ) {
		$url = 'https://' . ltrim( $url, '/' );
	}
	$url = esc_url_raw( $url, [ 'https', 'http' ] );
	if ( '' === $url ) {
		return null;
	}

	$label = mb_substr( sanitize_text_field( (string) ( $row['label'] ?? '' ) ), 0, 40 );
	if ( '' === $label ) {
		$label = (string) preg_replace( '/^www\./', '', (string) wp_parse_url( $url, PHP_URL_HOST ) );
	}

	$icon = absint( $row['icon_id'] ?? 0 );

	return [
		'id'      => preg_replace( '/[^a-z0-9]/', '', strtolower( (string) ( $row['id'] ?? '' ) ) ) ?: 'n' . substr( md5( $url . $label ), 0, 8 ),
		'label'   => $label,
		'url'     => $url,
		'icon_id' => $icon && wp_attachment_is_image( $icon ) ? $icon : 0,
	];
}

/**
 * شبکه‌های قدیمی (۳.۲.۲ و پیش از آن): دو کلید social_{شبکه}_url و _icon در گزینه تنظیمات.
 *
 * @param array<string, mixed> $settings گزینه خام تنظیمات
 * @return list<array{id:string, label:string, url:string, icon_id:int}>
 */
function hodima_social_legacy_items( array $settings ): array {

	$items = [];

	foreach ( hodima_social_legacy_networks() as $key => $label ) {
		$item = hodima_social_clean_item( [
			'id'      => 'legacy' . $key,
			'label'   => $label,
			'url'     => (string) ( $settings[ "social_{$key}_url" ] ?? '' ),
			'icon_id' => (int) ( $settings[ "social_{$key}_icon" ] ?? 0 ),
		] );
		if ( $item ) {
			$items[] = $item;
		}
	}

	return $items;
}

/** آیا مدیر فهرست تازه را ذخیره کرده؟ تا آن موقع شبکه‌های قدیمی خوانده می‌شوند (بدون مهاجرت مخرب). */
function hodima_social_saved(): bool {
	return is_array( get_option( HODIMA_SOCIAL_OPTION, false ) );
}

/**
 * شبکه‌های اجتماعی نوار فوتر، به ترتیب مدیر.
 *
 * @return list<array{id:string, label:string, url:string, icon_id:int}>
 */
function hodima_social_links(): array {

	if ( ! hodima_social_saved() ) {
		return hodima_social_legacy_items( (array) get_option( HODIMA_SETTINGS_OPTION, [] ) );
	}

	$items = [];

	foreach ( (array) get_option( HODIMA_SOCIAL_OPTION, [] ) as $row ) {
		$item = is_array( $row ) ? hodima_social_clean_item( $row ) : null;
		if ( $item ) {
			$items[] = $item;
		}
	}

	return array_slice( $items, 0, HODIMA_SOCIAL_MAX );
}

/**
 * پاک‌سازی گزینه. دو شکل ورودی:
 * - فرم پیشخوان: کلید `_sent` + هر ردیف با کلید یکتا (ترتیب = ترتیب ارسال)؛ ردیف بی‌آدرس کنار گذاشته می‌شود.
 * - فهرست تمیز (list): وردپرس هنگام ساخته شدن اولین‌باره گزینه (update_option ← add_option) callback را
 *   «دوباره» روی مقدار پاک‌شده اجرا می‌کند؛ بدون این شاخه اولین ذخیره همیشه فهرست خالی می‌شد (باگ 3.2.3 و 3.2.4).
 * هر چیز دیگر (ذخیره از جای دیگر): مقدار قبلی می‌ماند.
 *
 * @return list<array{id:string, label:string, url:string, icon_id:int}>
 */
function hodima_social_sanitize( mixed $input ): array {

	if ( ! is_array( $input ) || ( ! isset( $input['_sent'] ) && ! array_is_list( $input ) ) ) {
		return hodima_social_links();
	}

	$items = [];

	foreach ( $input as $uid => $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$item = hodima_social_clean_item( ( is_string( $uid ) ? [ 'id' => $uid ] : [] ) + $row );
		if ( $item ) {
			$items[] = $item;
		}
	}

	return array_slice( $items, 0, HODIMA_SOCIAL_MAX );
}

/**
 * نمادهای اعتماد دارای تصویر، به ترتیب ۱ تا ۳ (نماد بدون تصویر رد می‌شود).
 *
 * @return list<array{image_id:int, url:string}>
 */
function hodima_trust_badges(): array {

	$badges = [];

	for ( $i = 1; $i <= HODIMA_TRUST_SLOTS; $i++ ) {
		$suffix   = 1 === $i ? '' : "_{$i}";
		$image_id = (int) hodima_setting( "trust_image_id{$suffix}" );

		if ( $image_id && wp_attachment_is_image( $image_id ) ) {
			$badges[] = [ 'image_id' => $image_id, 'url' => (string) hodima_setting( "trust_url{$suffix}" ) ];
		}
	}

	return $badges;
}

/**
 * مسیر یک آدرس برای مقایسه: بدون دامنه، پارامتر و پوشه نصب وردپرس، رمزگشایی‌شده
 * (نامک فارسی کپی‌شده از نوار آدرس کدگذاری شده است)، با / در ابتدا و انتها.
 */
function hodima_normalize_path( string $url ): string {

	$path = rawurldecode( (string) wp_parse_url( $url, PHP_URL_PATH ) );
	$base = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );

	if ( '' !== $base && str_starts_with( $path, $base . '/' ) ) {
		$path = substr( $path, strlen( $base ) );
	}

	$path = trim( strtolower( $path ), '/' ); // strtolower در PHP 8 فقط ASCII را تغییر می‌دهد؛ نامک فارسی سالم می‌ماند

	return '' === $path ? '/' : '/' . $path . '/';
}

/**
 * آیا نوار شبکه‌های اجتماعی در صفحه فعلی نمایش داده شود؟
 * صفحه‌های فهرست «social_hide_urls» مستثنا هستند؛ خط با * در انتها همه زیرصفحه‌ها را هم می‌گیرد.
 */
function hodima_socials_visible_here(): bool {

	$rules = trim( (string) hodima_setting( 'social_hide_urls' ) );
	$show  = true;

	if ( '' !== $rules ) {
		$current = hodima_normalize_path( (string) wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- فقط مقایسه مسیر

		foreach ( preg_split( '/\R/u', $rules ) ?: [] as $rule ) {

			$rule = trim( $rule );
			if ( '' === $rule ) {
				continue;
			}

			$prefix = str_ends_with( $rule, '*' );
			$path   = hodima_normalize_path( rtrim( $rule, '*' ) );

			if ( $prefix ? str_starts_with( $current, $path ) : $current === $path ) {
				$show = false;
				break;
			}
		}
	}

	/** برای استثنای برنامه‌نویسی (مثلا بر اساس نوع صفحه). */
	return (bool) apply_filters( 'hodima_show_socials', $show );
}

/* =========================================================================
 * ۵. پالت رنگ برند (تب «برند و رنگ‌ها»)
 * ------------------------------------------------------------------------
 * فقط رنگ‌هایی که با پیش‌فرض فرق دارند به‌صورت :root{…} بعد از tokens.css
 * چاپ می‌شوند (سایت با پالت پیش‌فرض هیچ CSS اضافه‌ای ندارد). مشتق‌ها هم
 * دوباره ساخته می‌شوند: «R, G, B» برای رنگ‌های نیمه‌شفاف، نسخه تیره رنگ
 * اصلی (hover؛ ×۰٫۷۳ همان نسبت #1b244d به #25316a) و نقطه میانی گرادیان.
 * ========================================================================= */

/**
 * «#rrggbb» → [r, g, b]
 *
 * @return array{int, int, int}
 */
function hodima_hex_rgb( string $hex ): array {
	$hex = ltrim( $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	return array_map( 'hexdec', str_split( substr( str_pad( $hex, 6, '0' ), 0, 6 ), 2 ) );
}

/**
 * [r, g, b] → «#rrggbb»
 *
 * @param array<int, int|float> $rgb
 */
function hodima_rgb_hex( array $rgb ): string {
	return '#' . implode( '', array_map( static fn( $c ): string => str_pad( dechex( max( 0, min( 255, (int) round( $c ) ) ) ), 2, '0', STR_PAD_LEFT ), $rgb ) );
}

/** CSS پالت تنظیم‌شده، یا رشته خالی برای پالت پیش‌فرض. */
function hodima_palette_css(): string {

	$fields = hodima_settings_fields();
	$vars   = [];
	$map    = [
		'color_primary'      => 'primary',
		'color_secondary'    => 'secondary',
		'color_third'        => 'third',
		'color_accent'       => 'accent',
		'color_accent_light' => 'accent-light',
	];
	$changed = [];

	foreach ( $map as $key => $token ) {
		$value = strtolower( (string) hodima_setting( $key ) );
		if ( $value !== strtolower( (string) $fields[ $key ]['default'] ) && sanitize_hex_color( $value ) ) {
			$changed[ $token ]            = $value;
			$vars[ "--hodima-{$token}" ]     = $value;
			$vars[ "--hodima-{$token}-rgb" ] = implode( ', ', hodima_hex_rgb( $value ) );
		}
	}

	if ( ! $changed ) {
		return '';
	}

	$primary   = hodima_hex_rgb( (string) hodima_setting( 'color_primary' ) );
	$secondary = hodima_hex_rgb( (string) hodima_setting( 'color_secondary' ) );

	if ( isset( $changed['primary'] ) ) {
		$vars['--hodima-primary-dark'] = hodima_rgb_hex( array_map( static fn( $c ) => $c * 0.73, $primary ) );
	}

	if ( isset( $changed['primary'] ) || isset( $changed['secondary'] ) ) {
		$vars['--hodima-gradient-mid']  = hodima_rgb_hex( array_map( static fn( $a, $b ) => $a + ( $b - $a ) * 0.4, $primary, $secondary ) );
		$vars['--hodima-gradient-deep'] = hodima_rgb_hex( array_map( static fn( $a, $b ) => $a + ( $b - $a ) * 0.26, $primary, $secondary ) );
	}

	$css = '';
	foreach ( $vars as $name => $value ) {
		$css .= $name . ':' . $value . ';';
	}

	return ':root{' . $css . '}';
}

/** بعد از tokens.css در سایت و پیشخوان (همان handle). */
function hodima_print_palette(): void {
	$css = hodima_palette_css();
	if ( '' !== $css && wp_style_is( 'hodima-tokens', 'enqueued' ) ) {
		wp_add_inline_style( 'hodima-tokens', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'hodima_print_palette', 21 );
add_action( 'admin_enqueue_scripts', 'hodima_print_palette', 2 );

/* =========================================================================
 * ۶. Google Analytics 4
 * ========================================================================= */

add_action( 'wp_enqueue_scripts', 'hodima_enqueue_google_analytics', 1 );

function hodima_enqueue_google_analytics(): void {

	$ga_id = (string) hodima_setting( 'ga_id' );

	if ( '' === $ga_id || ! preg_match( '/^G-[A-Z0-9]{4,16}$/', $ga_id ) ) {
		return;
	}

	if ( hodima_setting( 'ga_production' ) && 'production' !== wp_get_environment_type() ) {
		return;
	}

	if ( hodima_setting( 'ga_skip_editors' ) && current_user_can( 'edit_posts' ) ) {
		return;
	}

	wp_enqueue_script(
		'hodima-gtag',
		'https://www.googletagmanager.com/gtag/js?id=' . rawurlencode( $ga_id ),
		[],
		null, // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- پارامتر نسخه به آدرس گوگل اضافه نشود
		[ 'in_footer' => false, 'strategy' => 'async' ]
	);

	wp_add_inline_script(
		'hodima-gtag',
		sprintf(
			'window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config",%s);',
			wp_json_encode( $ga_id )
		),
		'before'
	);
}

add_filter( 'wp_resource_hints', static function ( array $urls, string $relation ): array {
	if ( 'preconnect' === $relation && '' !== (string) hodima_setting( 'ga_id' ) ) {
		$urls[] = [ 'href' => 'https://www.googletagmanager.com', 'crossorigin' => 'anonymous' ];
	}
	return $urls;
}, 10, 2 );

/* =========================================================================
 * ۷. باطل کردن کش‌هایی که از این تنظیمات استفاده می‌کنند
 * ========================================================================= */

add_action( 'update_option_' . HODIMA_SETTINGS_OPTION, static function (): void {

	// llms.txt شماره‌های تماس را در خود دارد
	foreach ( [ 'fa', 'en' ] as $lang ) {
		foreach ( [ 20, 500 ] as $limit ) {
			delete_transient( "hodima_llms_txt_cache_{$lang}_{$limit}_siloed" );
		}
	}

	// هدر و فوتر در همه صفحات کش‌شده تغییر کرده‌اند
	do_action( 'litespeed_purge_all' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- API خود لایت‌اسپید
} );

// فهرست پویای شبکه‌های اجتماعی (فقط پیشخوان)
if ( is_admin() ) {
	require_once __DIR__ . '/social-admin.php';
}
