/**
 * Hodima — صفحه «تنظیمات قالب هدیما»
 * Path: inc/theme-settings/admin.js
 *
 * Vanilla JS (بدون jQuery). انتخابگر تصویر از API رسانه وردپرس (wp.media)
 * استفاده می‌کند که با wp_enqueue_media() بارگذاری می‌شود.
 */
(() => {
	'use strict';

	const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/**
	 * یک انتخابگر رسانه: دکمه انتخاب، پیش‌نمایش (با حالت «بدون تصویر»)، دکمه حذف و
	 * فیلد مخفی شناسه. data-hodima-media-kind="font": فایل فونت (نام فایل به‌جای
	 * تصویر؛ رویداد hodima:font برای پیش‌نمایش تایپوگرافی).
	 */
	const initMediaField = (root) => {
		const input = root.querySelector('[data-hodima-media-input]');
		const preview = root.querySelector('[data-hodima-media-preview]');
		const selectBtn = root.querySelector('[data-hodima-media-select]');
		const removeBtn = root.querySelector('[data-hodima-media-remove]');
		const isFont = root.dataset.hodimaMediaKind === 'font';
		const noun = isFont ? 'فایل' : 'تصویر';

		if (!input || !preview || !selectBtn || !removeBtn || typeof window.wp?.media !== 'function') {
			return;
		}

		let frame = null;

		const sample = root.querySelector('[data-hodima-font-sample]');

		const render = (attachment) => {
			preview.querySelector('img')?.remove();
			const name = preview.querySelector('[data-hodima-media-name]');
			if (sample) {
				sample.hidden = !attachment;
			}

			if (!attachment) {
				input.value = '';
				preview.classList.add('is-empty');
				if (name) {
					name.textContent = '';
				}
				removeBtn.hidden = true;
				selectBtn.textContent = `انتخاب ${noun}`;
				input.dispatchEvent(new Event('change', { bubbles: true }));
				return;
			}

			if (isFont) {
				if (name) {
					name.textContent = attachment.filename ?? '';
				}
				root.dispatchEvent(new CustomEvent('hodima:font', { bubbles: true, detail: { url: attachment.url, input } }));
			} else {
				const size = attachment.sizes?.medium ?? attachment.sizes?.full ?? attachment;
				const img = document.createElement('img');
				img.src = size.url;
				img.alt = '';
				img.decoding = 'async';
				preview.prepend(img);
			}

			preview.classList.remove('is-empty');
			input.value = String(attachment.id);
			removeBtn.hidden = false;
			selectBtn.textContent = `تغییر ${noun}`;
			// فیلد مخفی رویداد ندارد؛ برای نشانه «ذخیره‌نشده»
			input.dispatchEvent(new Event('change', { bubbles: true }));
		};

		selectBtn.addEventListener('click', () => {
			frame ??= window.wp.media({
				title: selectBtn.dataset.title ?? '',
				library: { type: isFont ? ['font/woff2', 'font/woff'] : 'image' },
				button: { text: `استفاده از این ${noun}` },
				multiple: false,
			});

			// اتصال یک‌باره؛ frame بین کلیک‌ها نگه داشته می‌شود
			if (!frame.hodimaBound) {
				frame.on('select', () => render(frame.state().get('selection').first()?.toJSON()));
				frame.hodimaBound = true;
			}

			frame.open();
		});

		removeBtn.addEventListener('click', () => {
			render(null);
			selectBtn.focus();
		});
	};

	/**
	 * تب «تایپوگرافی»: نمونه زنده. هر فیلد یک متغیر همان tokens.css را روی ظرف
	 * نمونه عوض می‌کند (فرمول‌ها در admin.css همان style.css‌اند).
	 */
	const initTypography = () => {
		const preview = document.querySelector('[data-hodima-type-preview]');
		if (!preview) {
			return;
		}

		const stacks = JSON.parse(preview.dataset.stacks ?? '{}');
		const field = (key) => document.getElementById(`hodima-setting-${key}`);
		const colorVar = (key, custom) => (key === 'custom' ? custom : key === 'text' ? 'var(--hodima-text-dark)' : `var(--hodima-${key})`);
		const set = (name, value) => {
			if (value !== undefined && value !== '') {
				preview.style.setProperty(name, value);
			}
		};

		const sync = () => {
			const body = field('font_body')?.value ?? 'vazirmatn';
			const heading = field('font_heading')?.value ?? 'body';
			set('--hodima-font', stacks[body]);
			set('--hodima-font-heading', heading === 'body' ? stacks[body] : stacks[heading]);
			set('--hodima-body-size', field('body_size')?.value);
			set('--hodima-body-line-height', field('body_line_height')?.value);
			set('--hodima-text-dark', field('color_text')?.value);
			set('--hodima-link', colorVar(field('link_color')?.value ?? 'secondary', field('link_color_custom')?.value));
			set('--hodima-link-hover', colorVar(field('link_hover_color')?.value ?? 'primary', field('link_hover_color_custom')?.value));
			set('--hodima-content-link-line', field('content_link_underline')?.checked === false ? 'none' : 'underline');

			for (let level = 1; level <= 6; level++) {
				set(`--hodima-h${level}-size-max`, field(`h${level}_size`)?.value);
				set(`--hodima-h${level}-size-min`, field(`h${level}_size_mobile`)?.value);
				set(`--hodima-h${level}-weight`, field(`h${level}_weight`)?.value);
				set(`--hodima-h${level}-line-height`, field(`h${level}_line_height`)?.value);
				set(`--hodima-h${level}-color`, colorVar(field(`h${level}_color`)?.value ?? 'text'));
			}
		};

		document.querySelector('[data-section="typography"]')?.addEventListener('input', sync);
		document.querySelector('[data-section="typography"]')?.addEventListener('change', sync);

		// فایل فونت تازه (پیش از ذخیره): همان‌جا به مرورگر اضافه شود
		document.addEventListener('hodima:font', async (event) => {
			const weight = event.detail.input?.id.match(/font_custom_(\d+)$/)?.[1];
			if (!weight || typeof FontFace !== 'function') {
				return;
			}
			try {
				const face = new FontFace(preview.dataset.family ?? 'Hodima Custom', `url("${event.detail.url}")`, { weight });
				document.fonts.add(await face.load());
			} catch {
				// فایل خراب یا نامعتبر: پیش‌نمایش با فونت جایگزین می‌ماند
			}
		});

		preview.querySelectorAll('[data-hodima-type-mode]').forEach((button) => {
			button.addEventListener('click', () => {
				preview.dataset.mode = button.dataset.hodimaTypeMode;
				preview.querySelectorAll('[data-hodima-type-mode]').forEach((other) => {
					other.setAttribute('aria-pressed', String(other === button));
				});
			});
		});

		sync();
	};

	/**
	 * منوی کناری: هر تب لینک ?tab=… است (بدون JS سرور پنل درست را نشان می‌دهد).
	 * اینجا جابه‌جایی بدون بارگذاری مجدد انجام می‌شود، آدرس صفحه و آدرس بازگشت
	 * فرم (_wp_http_referer) به‌روز می‌شوند تا بعد از «ذخیره» همان تب باز بماند.
	 */
	const initNav = () => {
		const nav = document.querySelector('[data-hodima-nav]');
		if (!nav) {
			return null;
		}

		const links = [...nav.querySelectorAll('[data-tab]')];
		const referer = document.querySelector('[data-hodima-form] input[name="_wp_http_referer"]');
		const panelOf = (link) => document.getElementById(link.getAttribute('aria-controls'));

		const activate = (link, { focus = false } = {}) => {
			links.forEach((item) => {
				const selected = item === link;
				if (selected) {
					item.setAttribute('aria-current', 'page');
				} else {
					item.removeAttribute('aria-current');
				}
				const panel = panelOf(item);
				if (panel) {
					panel.hidden = !selected;
				}
			});

			const url = new URL(window.location.href);
			url.searchParams.set('tab', link.dataset.tab);
			url.searchParams.delete('settings-updated');
			window.history.replaceState(null, '', url);

			if (referer) {
				const back = new URL(referer.value, window.location.origin);
				back.searchParams.set('tab', link.dataset.tab);
				back.searchParams.delete('settings-updated');
				referer.value = back.pathname + back.search;
			}

			// تب فعال در منوی لغزنده موبایل دیده شود
			link.scrollIntoView({ block: 'nearest', inline: 'nearest' });

			// صفحه‌خوان: تمرکز روی عنوان تب تازه (فقط با کیبورد؛ کلیک موس صفحه را جابه‌جا نکند)
			if (focus) {
				panelOf(link)?.querySelector('h2')?.focus({ preventScroll: true });
			}

			const top = document.querySelector('.hodima-settings__layout');
			if (top && top.getBoundingClientRect().top < 0) {
				top.scrollIntoView({ block: 'start', behavior: reducedMotion() ? 'auto' : 'smooth' });
			}
		};

		nav.addEventListener('click', (event) => {
			const link = event.target.closest('[data-tab]');
			if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.button !== 0) {
				return; // باز کردن در زبانه جدید دست نخورد
			}
			event.preventDefault();
			// detail === 0: فعال‌سازی با Enter
			activate(link, { focus: event.detail === 0 });
		});

		// اگر فیلدی نامعتبر در تب پنهان بود، همان تب باز شود
		document.querySelector('[data-hodima-form]')?.addEventListener('invalid', (event) => {
			const panel = event.target.closest('[data-section]');
			const link = panel && links.find((item) => item.getAttribute('aria-controls') === panel.id);
			if (link && panel.hidden) {
				activate(link);
			}
		}, true);

		return { links, panelOf };
	};

	/**
	 * نشانه «تغییرهای ذخیره‌نشده»: در نوار ذخیره و کنار تب‌هایی که تغییر کرده‌اند،
	 * هشدار مرورگر هنگام ترک صفحه، و Ctrl/⌘ + S برای ذخیره.
	 */
	const initDirty = (nav) => {
		const form = document.querySelector('[data-hodima-form]');
		if (!form) {
			return;
		}

		let dirty = false;
		let submitting = false;

		const mark = (target) => {
			// ورودی‌های فرم جدای بازگردانی پشتیبان (form=) جزو تنظیمات نیستند
			if (!target?.name || target.closest('template') || target.form !== form) {
				return;
			}
			dirty = true;
			form.classList.add('is-dirty');
			const panel = target.closest('[data-section]');
			const link = panel && nav?.links.find((item) => item.getAttribute('aria-controls') === panel.id);
			const dot = link?.querySelector('[data-hodima-dirty]');
			if (dot) {
				dot.hidden = false;
			}
		};

		form.addEventListener('input', (event) => mark(event.target));
		form.addEventListener('change', (event) => mark(event.target));
		// جابه‌جایی، افزودن و حذف بخش‌های صفحه اصلی (admin.js خودش رویداد می‌فرستد)
		form.addEventListener('hodima:changed', (event) => mark(event.target.querySelector('[name]') ?? form.querySelector('[data-hodima-home] [name]')));

		form.addEventListener('submit', () => {
			submitting = true;
		});

		window.addEventListener('beforeunload', (event) => {
			if (dirty && !submitting) {
				event.preventDefault();
				event.returnValue = '';
			}
		});

		document.addEventListener('keydown', (event) => {
			if ((event.ctrlKey || event.metaKey) && !event.altKey && event.key.toLowerCase() === 's') {
				event.preventDefault();
				form.requestSubmit(form.querySelector('[type="submit"][name="submit"]') ?? undefined);
			}
		});
	};

	/** پالت: نمونه زنده، مقدار هگز و دکمه «بازگشت به پیش‌فرض» هر رنگ. */
	/** «#abc»، «25316A» یا «#25316a» ← «#25316a»؛ نامعتبر ← null. */
	const normalizeHex = (raw) => {
		const hex = raw.trim().replace(/^#/, '').toLowerCase();
		if (/^[0-9a-f]{3}$/.test(hex)) {
			return `#${[...hex].map((digit) => digit + digit).join('')}`;
		}
		return /^[0-9a-f]{6}$/.test(hex) ? `#${hex}` : null;
	};

	/**
	 * دایره رنگ کنار انتخاب‌های «از پالت» (رنگ لینک، رنگ تیترها): رنگ گزینه انتخاب‌شده
	 * از کادرهای رنگ همین فرم (پالت و رنگ متن، حتی پیش از ذخیره).
	 */
	const syncColorDots = () => {
		document.querySelectorAll('[data-hodima-color-dot]').forEach((dot) => {
			const select = dot.parentElement?.querySelector('select');
			const source = select && document.getElementById(`hodima-setting-color_${select.value.replace('-', '_')}`);
			if (source) {
				dot.style.background = source.value;
			}
		});
	};

	/**
	 * «دلخواه» در فهرست رنگ لینک: مربع رنگ همان کارت انتخاب‌گر می‌شود و کد رنگ زیر فهرست
	 * می‌آید؛ با رنگ پالت، مربع فقط رنگ پالت را نشان می‌دهد (data-hodima-when-custom).
	 */
	const initCustomColor = () => {
		document.addEventListener('change', (event) => {
			const select = event.target;
			const card = select instanceof HTMLSelectElement ? select.closest('.hodima-field') : null;
			if (!card?.querySelector('[data-hodima-when-custom]')) {
				return;
			}
			const custom = select.value === 'custom';
			card.querySelectorAll('[data-hodima-when-custom]').forEach((part) => {
				part.hidden = !custom;
			});
			// «بازگشت به پیش‌فرض» فقط وقتی رنگ دلخواه با پیش‌فرضش فرق دارد
			const reset = card.querySelector('[data-hodima-color-reset]');
			const picker = card.querySelector('input[type="color"]');
			if (custom && reset && picker) {
				reset.hidden = picker.value.toLowerCase() === reset.dataset.hodimaColorReset;
			}
			card.querySelector('[data-hodima-color-dot]').hidden = custom;
		});
	};

	const initPalette = () => {
		const preview = document.querySelector('[data-hodima-palette-preview]');

		document.querySelectorAll('[data-hodima-color]').forEach((input) => {
			const field = input.closest('.hodima-field');
			const value = field?.querySelector('[data-hodima-color-value]');
			const reset = field?.querySelector('[data-hodima-color-reset]');

			const sync = () => {
				const color = input.value.toLowerCase();
				if (value && document.activeElement !== value) {
					value.value = color;
					value.removeAttribute('aria-invalid');
				}
				if (reset) {
					reset.hidden = color === reset.dataset.hodimaColorReset;
				}
				preview?.style.setProperty(`--pv-${input.dataset.hodimaColor}`, color);
				syncColorDots();
			};

			input.addEventListener('input', sync);
			reset?.addEventListener('click', () => {
				// تا 3.2.0 بی‌پرسش رنگ انتخابی را پاک می‌کرد؛ حالا مثل حذف بخش صفحه اصلی تایید می‌گیرد
				const name = field?.querySelector('.hodima-field__label')?.textContent?.trim() ?? 'این رنگ';
				// eslint-disable-next-line no-alert
				if (!window.confirm(`رنگ «${name}» از ${input.value.toLowerCase()} به پیش‌فرض ${reset.dataset.hodimaColorReset} برگردد؟ (بعد از «ذخیره» قطعی می‌شود)`)) {
					input.focus();
					return;
				}
				input.value = reset.dataset.hodimaColorReset;
				input.dispatchEvent(new Event('input', { bubbles: true }));
				input.focus();
			});

			// کد رنگ تایپی: معتبر ← همان لحظه روی کادر رنگ؛ نامعتبر هنگام خروج به رنگ فعلی برمی‌گردد
			value?.addEventListener('input', () => {
				const color = normalizeHex(value.value);
				value.toggleAttribute('aria-invalid', color === null && value.value.trim() !== '');
				if (color && color !== input.value.toLowerCase()) {
					input.value = color;
					input.dispatchEvent(new Event('input', { bubbles: true }));
				}
			});
			value?.addEventListener('change', () => {
				value.value = input.value.toLowerCase();
				value.removeAttribute('aria-invalid');
			});
		});

		document.querySelectorAll('[data-hodima-color-dot]').forEach((dot) => {
			dot.parentElement?.querySelector('select')?.addEventListener('change', syncColorDots);
		});
	};

	/** قاب جمع‌شونده (پیش‌نمایش تایپوگرافی): باز/بسته بودن برای همین مرورگر به خاطر می‌ماند. */
	const initCollapsible = () => {
		document.querySelectorAll('[data-hodima-collapsible]').forEach((panel) => {
			const key = `hodima-panel-open-${panel.dataset.hodimaCollapsible}`;
			// باز اجباری از سرور (مثلا فونت آپلودی انتخاب شده): حافظه مرورگر رویش نمی‌نشیند
			if (!panel.hasAttribute('data-hodima-keep-open')) {
				try {
					panel.open = window.localStorage.getItem(key) === '1';
				} catch {
					// بدون دسترسی به حافظه مرورگر: همان پیش‌فرض بسته
				}
			}
			// با انتخاب «فونت آپلودی» در فهرست‌های فونت، قاب خودش باز می‌شود
			(panel.dataset.hodimaOpenOn ?? '').split(' ').filter(Boolean).forEach((name) => {
				document.getElementById(`hodima-setting-${name}`)?.addEventListener('change', (event) => {
					if (event.target.value === 'custom') {
						panel.open = true;
					}
				});
			});
			panel.addEventListener('toggle', () => {
				try {
					window.localStorage.setItem(key, panel.open ? '1' : '0');
				} catch {
					// نادیده
				}
			});
		});
	};

	/**
	 * قاب «تیترها»: وزن، فاصله خطوط و رنگ «همه تیترها». کنترل کمکی (بی name) مقدار شش فیلد
	 * واقعی H1 تا H6 را عوض می‌کند و رویدادها را می‌فرستد تا نمونه زنده و مربع رنگ هم به‌روز شوند.
	 * عکس آن: با تغییر دستی یک تیتر، کنترل کمکی یا مقدار مشترک را نشان می‌دهد یا «متفاوت».
	 */
	const initHeadingsAll = () => {
		document.querySelectorAll('[id^="hodima-setting-all_"]').forEach((control) => {
			const kind = control.id.replace('hodima-setting-all_', '');
			const targets = [1, 2, 3, 4, 5, 6].map((level) => document.getElementById(`hodima-setting-h${level}_${kind}`)).filter(Boolean);
			const isSelect = control.tagName === 'SELECT';
			const same = (value) => (isSelect ? value : String(Number.parseFloat(value)));
			let applying = false; // هنگام نوشتن در شش فیلد، refresh کنترل کمکی را «متفاوت» نکند

			const refresh = () => {
				if (applying) {
					return;
				}
				const values = new Set(targets.map((target) => same(target.value)));
				if (values.size === 1) {
					const shared = targets[0].value;
					if (isSelect) {
						control.querySelector('option[value=""]')?.remove();
					}
					control.value = shared;
				} else {
					if (isSelect && !control.querySelector('option[value=""]')) {
						control.add(new Option('متفاوت (تنظیم جدا)', ''), 0);
					}
					control.value = '';
				}
				syncColorDots();
			};

			const apply = () => {
				if (control.value === '') {
					return;
				}
				applying = true;
				targets.forEach((target) => {
					if (target.value !== control.value) {
						target.value = control.value;
						target.dispatchEvent(new Event('input', { bubbles: true }));
						target.dispatchEvent(new Event('change', { bubbles: true }));
					}
				});
				applying = false;
				syncColorDots();
			};

			control.addEventListener(isSelect ? 'change' : 'input', apply);
			targets.forEach((target) => target.addEventListener('change', refresh));
			targets.forEach((target) => target.addEventListener('input', refresh));
		});
	};

	/**
	 * آیکون ؟ راهنما: با هاور و فوکوس باز می‌شود، با کلیک/لمس می‌ماند (موبایل)، با Esc یا کلیک بیرون بسته
	 * می‌شود. حباب fixed است تا از برش قاب‌ها (overflow) در امان بماند و با لبه صفحه برخورد نکند.
	 */
	const initTips = () => {
		const timers = new WeakMap();
		const tipOf = (target) => target.closest?.('.hodima-tip') ?? null;
		const place = (tip) => {
			const button = tip.querySelector('.hodima-tip__button');
			const bubble = tip.querySelector('.hodima-tip__bubble');
			const anchor = button.getBoundingClientRect();
			const { width, height } = bubble.getBoundingClientRect();
			const margin = 8;
			const left = Math.min(Math.max(anchor.left + anchor.width / 2 - width / 2, margin), Math.max(window.innerWidth - width - margin, margin));
			const below = anchor.bottom + margin + height <= window.innerHeight || anchor.top - margin - height < 0;
			bubble.style.insetInlineStart = 'auto';
			bubble.style.left = `${left}px`;
			bubble.style.top = `${below ? anchor.bottom + margin : anchor.top - margin - height}px`;
		};
		const show = (tip) => {
			window.clearTimeout(timers.get(tip));
			tip.classList.add('is-open');
			tip.querySelector('.hodima-tip__button').setAttribute('aria-expanded', 'true');
			place(tip);
		};
		const hide = (tip) => {
			window.clearTimeout(timers.get(tip));
			delete tip.dataset.pinned;
			tip.classList.remove('is-open');
			tip.querySelector('.hodima-tip__button').setAttribute('aria-expanded', 'false');
		};
		const hideAll = () => document.querySelectorAll('.hodima-tip.is-open').forEach(hide);
		const later = (tip) => timers.set(tip, window.setTimeout(() => !tip.dataset.pinned && hide(tip), 150));

		// رویدادها روی document (واگذاری): آیکون‌های بخش‌های تازه/کپی‌شده هم کار می‌کنند
		document.addEventListener('mouseover', (event) => {
			const tip = tipOf(event.target);
			if (tip && !tip.contains(event.relatedTarget)) {
				show(tip);
			}
		});
		document.addEventListener('mouseout', (event) => {
			const tip = tipOf(event.target);
			if (tip && !tip.contains(event.relatedTarget)) {
				later(tip);
			}
		});
		document.addEventListener('focusin', (event) => {
			const tip = tipOf(event.target);
			if (tip && event.target.matches('.hodima-tip__button')) {
				show(tip);
			}
		});
		document.addEventListener('focusout', (event) => {
			const tip = tipOf(event.target);
			if (tip && event.target.matches('.hodima-tip__button')) {
				later(tip);
			}
		});
		document.addEventListener('click', (event) => {
			const tip = tipOf(event.target);
			if (!tip) {
				hideAll();
				return;
			}
			if (!event.target.closest('.hodima-tip__button')) {
				return;
			}
			if (tip.dataset.pinned) {
				hide(tip);
			} else {
				hideAll();
				show(tip);
				tip.dataset.pinned = '1';
			}
		});
		document.addEventListener('keydown', (event) => event.key === 'Escape' && hideAll());
		window.addEventListener('scroll', hideAll, { passive: true, capture: true });
		window.addEventListener('resize', hideAll);
	};

	/** پیش‌نمایش لوگو روی رنگ هدر، هم‌زمان با کلید «لوگو سفید نمایش داده شود». */
	const initLogoInvert = () => {
		document.querySelectorAll('[data-hodima-invert-source]').forEach((preview) => {
			const source = document.getElementById(preview.dataset.hodimaInvertSource);
			source?.addEventListener('change', () => preview.classList.toggle('is-inverted', source.checked));
		});
	};

	/** برچسب «در حال استفاده» قاب بخش‌های صفحه اصلی، هم‌زمان با کلید ساخت از چیدمان. */
	const initBuilderStatus = () => {
		const status = document.querySelector('[data-hodima-builder-status]');
		const source = document.getElementById('hodima-setting-home_builder');
		if (!status || !source) {
			return;
		}

		// کلید روشن + صفحه اصلی برگه + دست‌کم یک بخش روشن ← «در حال استفاده»؛ کلید روشن بدون این دو ← «اعمال نمی‌شود»
		const update = () => {
			const anyEnabled = document.querySelector('[data-hodima-home-item] .hodima-home__switch input:checked') !== null;
			const state = !source.checked ? 'off' : (status.dataset.pageOk === '1' && anyEnabled ? 'on' : 'blocked');
			status.classList.toggle('is-on', state === 'on');
			status.classList.toggle('is-blocked', state === 'blocked');
			status.textContent = status.dataset[state];
		};

		source.addEventListener('change', update);
		document.addEventListener('change', (event) => event.target.closest?.('[data-hodima-home-item]') && update());
		document.addEventListener('hodima:changed', update); // افزودن/حذف/جابه‌جایی بخش
	};

	/**
	 * تب «صفحه اصلی»: فهرست بخش‌ها (inc/theme-settings/home-layout-admin.php).
	 * ترتیب ذخیره = ترتیب بخش‌ها در فرم؛ پس جابه‌جایی فقط جابه‌جایی عنصر است.
	 * کشیدن با دستگیره، و برای کیبورد/صفحه‌خوان دکمه‌های بالا/پایین.
	 */
	const initHomeLayout = (root) => {
		const list = root.querySelector('[data-hodima-home-list]');
		const empty = root.querySelector('[data-hodima-home-empty]');
		const typeSelect = root.querySelector('[data-hodima-home-type]');
		const live = document.createElement('p');

		if (!list || !typeSelect) {
			return;
		}

		// اعلان تغییرها برای صفحه‌خوان (جابه‌جایی، افزودن، حذف)
		live.className = 'screen-reader-text';
		live.setAttribute('aria-live', 'polite');
		root.append(live);
		const announce = (text) => {
			live.textContent = '';
			window.setTimeout(() => { live.textContent = text; }, 50);
			// جابه‌جایی/افزودن/حذف رویداد input ندارد؛ برای نشانه «ذخیره‌نشده»
			list.dispatchEvent(new CustomEvent('hodima:changed', { bubbles: true }));
		};

		const items = () => [...list.querySelectorAll(':scope > [data-hodima-home-item]')];
		const labelOf = (item) => item.querySelector('.hodima-home__title strong')?.textContent ?? '';

		/** بخش‌های تک‌نمونه (معرفی، دسته‌ها، …) وقتی هست دوباره قابل افزودن نیستند. */
		const refresh = () => {
			const present = new Set(items().map((item) => item.dataset.type));
			[...typeSelect.options].forEach((option) => {
				option.disabled = option.dataset.single === '1' && present.has(option.value);
			});
			if (typeSelect.selectedOptions[0]?.disabled) {
				typeSelect.value = [...typeSelect.options].find((option) => !option.disabled)?.value ?? '';
			}
			if (empty) {
				empty.hidden = items().length > 0;
			}
		};

		const toggleBody = (item, open) => {
			const button = item.querySelector('[data-hodima-home-toggle]');
			const body = item.querySelector('.hodima-home__body');
			if (!button || !body) {
				return;
			}
			const next = open ?? button.getAttribute('aria-expanded') !== 'true';
			button.setAttribute('aria-expanded', String(next));
			body.hidden = !next;
		};

		const move = (item, direction) => {
			const sibling = direction === 'up' ? item.previousElementSibling : item.nextElementSibling;
			if (!sibling) {
				return;
			}
			if (direction === 'up') {
				sibling.before(item);
			} else {
				sibling.after(item);
			}
			announce(`«${labelOf(item)}» جابه‌جا شد: ردیف ${items().indexOf(item) + 1} از ${items().length}`);
		};

		/** کپی بخش (فقط انواع چندنمونه‌ای): همه مقدارهای فعلی فرم، با شناسه تازه، درست زیر بخش اصلی. */
		const duplicate = (item) => {
			const uidOf = (element) => element.querySelector('[name]')?.getAttribute('name')?.match(/\[([^\]]+)\]/)?.[1];
			const oldUid = uidOf(item);
			if (!oldUid) {
				return;
			}
			const uid = `n${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
			const copy = item.cloneNode(true);

			copy.querySelectorAll('[name], [id], [for], [aria-controls]').forEach((element) => {
				['name', 'id', 'for', 'aria-controls'].forEach((attribute) => {
					const value = element.getAttribute(attribute);
					if (value) {
						element.setAttribute(attribute, value.replaceAll(`[${oldUid}]`, `[${uid}]`).replaceAll(`hodima-home-${oldUid}-`, `hodima-home-${uid}-`));
					}
				});
			});

			// cloneNode فقط مقدار «اولیه» را می‌برد؛ مقدار فعلی (تایپ‌شده/تیک‌خورده) را دستی می‌نویسیم
			const from = [...item.querySelectorAll('input, select, textarea')];
			[...copy.querySelectorAll('input, select, textarea')].forEach((field, index) => {
				if (field.type === 'checkbox' || field.type === 'radio') {
					field.checked = from[index].checked;
				} else {
					field.value = from[index].value;
				}
			});

			item.after(copy);
			refresh();
			toggleBody(copy, true);
			copy.scrollIntoView({ block: 'nearest', behavior: reducedMotion() ? 'auto' : 'smooth' });
			copy.querySelector('[data-hodima-home-toggle]')?.focus();
			announce(`از «${labelOf(item)}» یک کپی ساخته شد (ردیف ${items().indexOf(copy) + 1})`);
		};

		root.querySelector('[data-hodima-home-add]')?.addEventListener('click', () => {
			const template = root.querySelector(`template[data-hodima-home-template="${CSS.escape(typeSelect.value)}"]`);
			if (!template) {
				return;
			}
			const uid = `n${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
			const holder = document.createElement('div');
			holder.innerHTML = template.innerHTML.replaceAll('__UID__', uid).replaceAll('__uid__', uid);
			const item = holder.firstElementChild;
			list.append(item);
			refresh();
			item.scrollIntoView({ block: 'nearest', behavior: reducedMotion() ? 'auto' : 'smooth' });
			item.querySelector('[data-hodima-home-toggle]')?.focus();
			announce(`بخش «${labelOf(item)}» به انتهای فهرست اضافه شد`);
		});

		list.addEventListener('click', (event) => {
			const item = event.target.closest('[data-hodima-home-item]');
			if (!item) {
				return;
			}
			if (event.target.closest('[data-hodima-home-toggle]')) {
				toggleBody(item);
				return;
			}
			if (event.target.closest('[data-hodima-home-duplicate]')) {
				duplicate(item);
				return;
			}
			const mover = event.target.closest('[data-hodima-home-move]');
			if (mover) {
				move(item, mover.dataset.hodimaHomeMove);
				mover.focus();
				return;
			}
			if (event.target.closest('[data-hodima-home-remove]')) {
				// eslint-disable-next-line no-alert
				if (window.confirm(`بخش «${labelOf(item)}» از صفحه اصلی حذف شود؟ (بعد از «ذخیره» قطعی می‌شود)`)) {
					const next = item.nextElementSibling ?? item.previousElementSibling;
					const label = labelOf(item);
					item.remove();
					refresh();
					(next?.querySelector('[data-hodima-home-toggle]') ?? typeSelect).focus();
					announce(`بخش «${label}» حذف شد`);
				}
			}
		});

		// جستجو در فهرست دسته‌ها: فقط نمایش را فیلتر می‌کند (تیک‌های مخفی‌شده همچنان ارسال می‌شوند)
		list.addEventListener('input', (event) => {
			const filter = event.target.closest?.('[data-hodima-home-filter]');
			if (!filter) {
				return;
			}
			const needle = filter.value.trim().toLowerCase();
			filter.closest('fieldset')?.querySelectorAll('[data-hodima-home-check]').forEach((label) => {
				label.hidden = needle !== '' && !label.textContent.toLowerCase().includes(needle);
			});
		});
		// Enter داخل کادر جستجو فرم را ارسال نکند
		list.addEventListener('keydown', (event) => {
			if (event.key === 'Enter' && event.target.closest?.('[data-hodima-home-filter]')) {
				event.preventDefault();
			}
		});

		// خلاصه جلوی نام بخش با تایپ عنوان یا انتخاب دسته به‌روز شود
		list.addEventListener('input', (event) => {
			const source = event.target.closest('[data-hodima-home-summary-source]');
			const item = source?.closest('[data-hodima-home-item]');
			const summary = item?.querySelector('[data-hodima-home-summary]');
			if (!summary) {
				return;
			}
			const sources = [...item.querySelectorAll('[data-hodima-home-summary-source]')];
			const title = sources.find((el) => el.tagName === 'INPUT')?.value.trim();
			const category = sources.find((el) => el.tagName === 'SELECT');
			summary.textContent = title || (category?.value ? category.selectedOptions[0]?.textContent.trim() : '') || '';
		});

		// کشیدن و رها کردن: فقط از دستگیره شروع می‌شود (تا انتخاب متن فیلدها خراب نشود)
		let dragged = null;
		list.addEventListener('pointerdown', (event) => {
			const handle = event.target.closest('[data-hodima-home-handle]');
			const item = handle?.closest('[data-hodima-home-item]');
			if (item) {
				item.draggable = true;
			}
		});
		list.addEventListener('dragstart', (event) => {
			dragged = event.target.closest('[data-hodima-home-item]');
			if (!dragged) {
				return;
			}
			event.dataTransfer.effectAllowed = 'move';
			event.dataTransfer.setData('text/plain', '');
			dragged.classList.add('is-dragging');
		});
		list.addEventListener('dragover', (event) => {
			if (!dragged) {
				return;
			}
			event.preventDefault();
			const over = event.target.closest('[data-hodima-home-item]');
			if (!over || over === dragged) {
				return;
			}
			const box = over.getBoundingClientRect();
			if (event.clientY < box.top + box.height / 2) {
				over.before(dragged);
			} else {
				over.after(dragged);
			}
		});
		list.addEventListener('dragend', () => {
			if (dragged) {
				dragged.classList.remove('is-dragging');
				dragged.draggable = false;
				announce(`«${labelOf(dragged)}» در ردیف ${items().indexOf(dragged) + 1} قرار گرفت`);
				dragged = null;
			}
		});

		root.querySelector('[data-hodima-home-import]')?.addEventListener('click', (event) => {
			// eslint-disable-next-line no-alert
			if (!window.confirm('چیدمان فعلی کنار گذاشته شود و دوباره از روی متن برگه صفحه اصلی ساخته شود؟ (بقیه تنظیمات این صفحه هم ذخیره می‌شوند)')) {
				event.preventDefault();
			}
		});

		refresh();
	};

	/** تب «ظاهر عمومی»: گردی گوشه‌ها، سبک دکمه و عرض در نمونه زنده. */
	const initLook = () => {
		const preview = document.querySelector('[data-hodima-look-preview]');
		if (!preview) {
			return;
		}

		const scales = JSON.parse(preview.dataset.scales ?? '{}');
		const buttons = JSON.parse(preview.dataset.buttons ?? '{}');
		const field = (key) => document.getElementById(`hodima-setting-${key}`);
		const width = preview.querySelector('[data-hodima-look-width]');
		const faDigits = (value) => String(value).replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[digit]);

		const sync = () => {
			const scale = scales[field('radius_style')?.value ?? 'default'];
			const [bg, hover] = buttons[field('button_style')?.value ?? 'gradient'] ?? [];
			if (scale !== undefined) {
				preview.style.setProperty('--hodima-radius-scale', scale);
			}
			if (bg && hover) {
				preview.style.setProperty('--hodima-button-bg', bg);
				preview.style.setProperty('--hodima-button-bg-hover', hover);
			}
			if (width) {
				width.textContent = faDigits(field('container_width')?.value ?? '');
			}
		};

		const section = document.querySelector('[data-section="layout"]');
		section?.addEventListener('input', sync);
		section?.addEventListener('change', sync);
		sync();
	};

	/**
	 * «دامنه‌های پیدا شده» (تب دامنه ویدئو): دکمه افزودن، دامنه را خط آخر کادر
	 * می‌گذارد؛ رویداد input نشانه «ذخیره‌نشده» را روشن می‌کند (initDirty).
	 */
	const initHosts = () => {
		document.querySelectorAll('[data-hodima-hosts]').forEach((box) => {
			const field = document.getElementById(box.dataset.hodimaHosts);
			if (!field) {
				return;
			}

			box.addEventListener('click', (event) => {
				const button = event.target.closest('[data-hodima-host]');
				if (!button || button.disabled) {
					return;
				}

				const lines = field.value.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
				lines.push(button.dataset.hodimaHost);
				field.value = lines.join('\n');
				field.dispatchEvent(new Event('input', { bubbles: true }));

				button.disabled = true;
				button.querySelector('.dashicons')?.classList.replace('dashicons-plus-alt2', 'dashicons-yes');
			});
		});
	};

	/** بازگردانی پشتیبان: تأیید پیش از جایگزینی همه تنظیمات. */
	const initBackup = () => {
		// نام فایل انتخاب‌شده کنار دکمه «انتخاب فایل»
		document.querySelectorAll('[data-hodima-file]').forEach((input) => {
			const name = input.parentElement?.querySelector('[data-hodima-file-name]');
			input.addEventListener('change', () => {
				if (name) {
					name.textContent = input.files?.[0]?.name ?? 'فایلی انتخاب نشده';
				}
			});
		});

		document.querySelector('[data-hodima-import-form]')?.addEventListener('submit', (event) => {
			// eslint-disable-next-line no-alert
			if (!window.confirm('همه تنظیمات فعلی قالب با فایل پشتیبان جایگزین شود؟')) {
				event.preventDefault();
			}
		});
	};

	document.addEventListener('DOMContentLoaded', () => {
		document.querySelectorAll('[data-hodima-media]').forEach(initMediaField);
		document.querySelectorAll('[data-hodima-home]').forEach(initHomeLayout);
		initDirty(initNav());
		initPalette();
		initCustomColor();
		initCollapsible();
		initLogoInvert();
		initTips();
		initHeadingsAll();
		initBuilderStatus();
		initTypography();
		initLook();
		initHosts();
		initBackup();
	});
})();
