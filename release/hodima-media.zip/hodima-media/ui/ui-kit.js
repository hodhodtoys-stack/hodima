/**
 * کیت UI مشترک پیشخوان هدیما — رفتار اجزا (منبع واحد؛ استایل: ui-kit.css؛ اسکیل hodima-admin-ui)
 *
 * - .hdm-tabset: تب‌ها (ARIA tabs؛ فلش، Home/End؛ فیلد نامعتبر در تب پنهان تبش را باز می‌کند).
 * - [data-hdm-media]: انتخاب‌گر رسانه (کتابخانه وردپرس، برداشتن، پیش‌نمایش از فیلد آدرس).
 * - [data-hdm-repeat]: لیست تکرارشونده (افزودن از <template>، جابه‌جایی، حذف با بازگردانی،
 *   شماره‌گذاری دوباره نام/شناسه/برچسب‌ها).
 * فقط داخل .hdm-ui کار می‌کند. پیشوند نام‌ها در ساخت به پیشوند بسته عوض می‌شود (tools/ui-kit/kit.py؛
 * کپی را دستی ویرایش نکن). رویدادها: input/change، hdm:tab-change و hdm:repeat-change
 * (حباب‌دار). بدون JS تب‌ها پنهان و همه بخش‌ها پشت‌سرهم دیده می‌شوند. زیر ESLint بدون baseline.
 */
( () => {
	'use strict';

	const fire = ( input ) => {
		input.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
	};

	/* ── تب‌ها ── */
	const initTabset = ( set ) => {
		const list = set.querySelector( '[role="tablist"]' );
		const tabs = [ ...set.querySelectorAll( '[role="tab"]' ) ];
		if ( ! list || ! tabs.length ) {
			return;
		}
		const panelOf = ( tab ) => document.getElementById( tab.getAttribute( 'aria-controls' ) );
		const select = ( tab, focus ) => {
			tabs.forEach( ( item ) => {
				const on = item === tab;
				item.setAttribute( 'aria-selected', String( on ) );
				item.tabIndex = on ? 0 : -1;
				const panel = panelOf( item );
				if ( panel ) {
					panel.hidden = ! on;
				}
			} );
			if ( focus ) {
				tab.focus();
			}
			set.dispatchEvent( new CustomEvent( 'hdm:tab-change', { bubbles: true, detail: { tab } } ) );
		};

		list.hidden = false;
		select( tabs.find( ( tab ) => 'true' === tab.getAttribute( 'aria-selected' ) ) ?? tabs[ 0 ], false );

		tabs.forEach( ( tab, i ) => {
			tab.addEventListener( 'click', () => select( tab, false ) );
			tab.addEventListener( 'keydown', ( e ) => {
				// راست‌به‌چپ: فلش چپ = تب بعدی
				const rtl = 'rtl' === getComputedStyle( list ).direction;
				const next = rtl ? 'ArrowLeft' : 'ArrowRight';
				const prev = rtl ? 'ArrowRight' : 'ArrowLeft';
				let target = null;
				if ( e.key === next ) {
					target = tabs[ ( i + 1 ) % tabs.length ];
				} else if ( e.key === prev ) {
					target = tabs[ ( i - 1 + tabs.length ) % tabs.length ];
				} else if ( 'Home' === e.key ) {
					target = tabs[ 0 ];
				} else if ( 'End' === e.key ) {
					target = tabs[ tabs.length - 1 ];
				}
				if ( target ) {
					e.preventDefault();
					select( target, true );
				}
			} );
		} );

		// فیلد نامعتبر در تب پنهان: تبش باز شود تا مرورگر بتواند نشانش بدهد
		set.addEventListener( 'invalid', ( e ) => {
			const panel = e.target.closest?.( '[role="tabpanel"]' );
			if ( panel?.hidden ) {
				const tab = tabs.find( ( item ) => item.getAttribute( 'aria-controls' ) === panel.id );
				if ( tab ) {
					select( tab, false );
				}
			}
		}, true );
	};

	/* ── انتخاب‌گر رسانه ── */
	const syncMedia = ( box ) => {
		const input = box.querySelector( '[data-hdm-media-input]' );
		const img = box.querySelector( '[data-hdm-media-img]' );
		if ( ! input ) {
			return;
		}
		const ok = /^https?:\/\//i.test( input.value.trim() );
		if ( img ) {
			if ( ok ) {
				img.src = input.value.trim();
			} else {
				img.removeAttribute( 'src' );
			}
			img.hidden = ! ok;
		}
		box.classList.toggle( 'is-empty', ! ok );
	};

	const pickMedia = ( box ) => {
		const input = box.querySelector( '[data-hdm-media-input]' );
		// بدون کتابخانه رسانه وردپرس (مثل ابزار تست) فقط فیلد آدرس کار می‌کند
		if ( ! input || typeof wp === 'undefined' || ! wp.media ) {
			return;
		}
		const frame = wp.media( {
			title: box.dataset.hdmMediaTitle || 'انتخاب تصویر',
			button: { text: box.dataset.hdmMediaButton || 'استفاده از این تصویر' },
			library: { type: 'image' },
			multiple: false,
		} );
		frame.on( 'select', () => {
			input.value = frame.state().get( 'selection' ).first().toJSON().url;
			fire( input );
		} );
		frame.open();
	};

	const initMedia = () => {
		document.querySelectorAll( '.hdm-ui [data-hdm-media]' ).forEach( syncMedia );
		document.addEventListener( 'click', ( e ) => {
			const pick = e.target.closest?.( '[data-hdm-media-pick]' );
			const clear = e.target.closest?.( '[data-hdm-media-clear]' );
			const box = ( pick ?? clear )?.closest( '[data-hdm-media]' );
			if ( ! box?.closest( '.hdm-ui' ) ) {
				return;
			}
			if ( pick ) {
				pickMedia( box );
			} else {
				const input = box.querySelector( '[data-hdm-media-input]' );
				input.value = '';
				fire( input );
				input.focus();
			}
		} );
		document.addEventListener( 'input', ( e ) => {
			if ( e.target.matches?.( '[data-hdm-media-input]' ) ) {
				const box = e.target.closest( '[data-hdm-media]' );
				if ( box?.closest( '.hdm-ui' ) ) {
					syncMedia( box );
				}
			}
		} );
	};

	/* ── لیست تکرارشونده ── */
	const initRepeat = ( root ) => {
		const rows = root.querySelector( '[data-hdm-rows]' );
		const template = root.querySelector( '[data-hdm-row-template]' );
		const addBtn = root.querySelector( '[data-hdm-add]' );
		const empty = root.querySelector( '[data-hdm-empty]' );
		const undoBox = root.querySelector( '[data-hdm-undo]' );
		const count = root.querySelector( '[data-hdm-count]' );
		if ( ! rows || ! template || ! addBtn ) {
			return;
		}
		const max = Number( root.dataset.hdmMax || 99 );
		const name = root.dataset.hdmName ?? '';
		const idPrefix = root.dataset.hdmId ?? '';
		const faNum = ( n ) => new Intl.NumberFormat( 'fa-IR' ).format( n );
		const quote = ( text ) => text.replace( /[.*+?^${}()|[\]\\]/g, '\\$&' );
		const nameRe = new RegExp( `^${ quote( name ) }\\[[^\\]]*\\]` );
		const idRe = new RegExp( `^${ quote( idPrefix ) }-[^-]+-` );
		const rowEls = () => [ ...rows.querySelectorAll( ':scope > [data-hdm-row]' ) ];
		const changed = () => root.dispatchEvent( new CustomEvent( 'hdm:repeat-change', { bubbles: true } ) );

		/** نام، شناسه، برچسب و aria-label هر ردیف به ترتیب فعلی (ذخیره همان ترتیب آرایه است). */
		const reindex = () => {
			const list = rowEls();
			list.forEach( ( row, i ) => {
				const n = faNum( i + 1 );
				row.querySelectorAll( `[name^="${ name }["]` ).forEach( ( input ) => {
					input.name = input.name.replace( nameRe, `${ name }[${ i }]` );
				} );
				row.querySelectorAll( `[id^="${ idPrefix }-"]` ).forEach( ( node ) => {
					node.id = node.id.replace( idRe, `${ idPrefix }-${ i }-` );
				} );
				row.querySelectorAll( `label[for^="${ idPrefix }-"]` ).forEach( ( label ) => {
					label.htmlFor = label.htmlFor.replace( idRe, `${ idPrefix }-${ i }-` );
				} );
				row.querySelectorAll( '[data-hdm-n]' ).forEach( ( node ) => {
					node.textContent = n;
				} );
				row.querySelectorAll( '[data-hdm-label]' ).forEach( ( btn ) => {
					btn.setAttribute( 'aria-label', btn.dataset.hdmLabel.replace( '%s', n ) );
				} );
				const up = row.querySelector( '[data-hdm-move="-1"]' );
				const down = row.querySelector( '[data-hdm-move="1"]' );
				if ( up ) {
					up.disabled = 0 === i;
				}
				if ( down ) {
					down.disabled = i === list.length - 1;
				}
			} );
			if ( empty ) {
				empty.hidden = list.length > 0;
			}
			if ( count ) {
				count.textContent = ( root.dataset.hdmCountText || '%s' ).replace( '%s', faNum( list.length ) );
			}
			addBtn.disabled = list.length >= max;
			addBtn.title = addBtn.disabled ? `حداکثر ${ faNum( max ) }` : '';
		};

		const clearUndo = () => undoBox?.replaceChildren();

		const add = () => {
			if ( rowEls().length >= max ) {
				return;
			}
			const row = template.content.cloneNode( true ).querySelector( '[data-hdm-row]' );
			rows.append( row );
			reindex();
			clearUndo();
			row.querySelector( '[data-hdm-row-title]' )?.focus();
			changed();
		};

		const remove = ( row ) => {
			const index = rowEls().indexOf( row );
			const label = row.querySelector( '[data-hdm-row-title]' )?.value.trim()
				|| `${ root.dataset.hdmItem || 'ردیف' } ${ faNum( index + 1 ) }`;
			row.remove();
			reindex();
			changed();
			if ( ! undoBox ) {
				return;
			}
			// بازگردانی به‌جای پنجره تأیید: ردیف تا ذخیره نوشته از دست نرفته است
			const undo = document.createElement( 'button' );
			undo.type = 'button';
			undo.className = 'button-link hdm-undo-btn';
			undo.textContent = root.dataset.hdmUndoLabel || 'بازگردانی';
			undo.addEventListener( 'click', () => {
				rows.insertBefore( row, rowEls()[ index ] ?? null );
				clearUndo();
				reindex();
				changed();
				row.querySelector( '[data-hdm-row-title]' )?.focus();
			} );
			const message = document.createElement( 'span' );
			message.textContent = `${ ( root.dataset.hdmRemovedText || '«%s» حذف شد.' ).replace( '%s', label ) } `;
			undoBox.replaceChildren( message, undo );
			undo.focus();
		};

		const move = ( row, dir ) => {
			const list = rowEls();
			const i = list.indexOf( row );
			const j = i + dir;
			if ( j < 0 || j >= list.length ) {
				return;
			}
			rows.insertBefore( dir < 0 ? row : list[ j ], dir < 0 ? list[ j ] : row );
			reindex();
			// فوکوس روی همان دکمه بماند تا چند بار پشت سر هم جابه‌جا شود (اگر هنوز فعال است)
			const same = row.querySelector( `[data-hdm-move="${ dir }"]` );
			( same.disabled ? row.querySelector( `[data-hdm-move="${ -dir }"]` ) : same ).focus();
			changed();
		};

		addBtn.addEventListener( 'click', add );
		rows.addEventListener( 'click', ( e ) => {
			const btn = e.target.closest( 'button' );
			const row = btn?.closest( '[data-hdm-row]' );
			if ( ! row ) {
				return;
			}
			if ( btn.hasAttribute( 'data-hdm-remove' ) ) {
				remove( row );
			} else if ( btn.hasAttribute( 'data-hdm-move' ) ) {
				move( row, Number( btn.dataset.hdmMove ) );
			}
		} );
		reindex();
	};

	const init = () => {
		document.querySelectorAll( '.hdm-ui .hdm-tabset' ).forEach( initTabset );
		document.querySelectorAll( '.hdm-ui [data-hdm-repeat]' ).forEach( initRepeat );
		initMedia();
	};

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
