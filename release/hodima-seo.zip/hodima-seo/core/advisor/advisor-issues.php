<?php
/**
 * ماژول «دستار سئو» — فهرست واحد ایرادهای فنی (SEO 3.3.5)
 * Path: core/advisor/advisor-issues.php
 *
 * هر ایراد خزنده یک رکورد دارد: برچسب، سطح، سختی (۱ = چند دقیقه، ۲ = ویرایش محتوا یا لینک، ۳ = کار بزرگ‌تر یا فنی) و دستور.
 * قبلا برچسب و دستور در advisor-crawl.php یک آرایه بزرگ بودند و هیچ‌کدام نمی‌دانستند صفحه محصول است یا دسته؛ حالا دستور
 * جای «ویرایش» همان نوع صفحه را می‌گیرد (`{where}`؛ مثلا «ویرایش محصول»، «ویرایش دسته»). فقط می‌خواند؛ چیزی را عوض نمی‌کند.
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * رکورد همه ایرادهای خزنده.
 *
 * `ref` = مرجع هر ایراد (قانون ثابت دستار): `google:<صفحه Search Central>` و/یا `refs:<پروژه‌های مرجع>`؛ `own` = بدون مرجع (فقط سطح اطلاع).
 * ایراد قرمز/کهربایی بدون مرجع گوگل یا دست‌کم ۳ پروژه مرجع رد می‌شود (advisor-checks-tests.php).
 *
 * @return array<string, array{label: string, level: string, effort: int, fix: string, ref: string}>
 */
function hodima_seo_advisor_issue_catalog(): array {

	static $catalog = null;

	// طول عنوان/متا با پیکسل، همان خط‌کش سئوباکس (seobox-metrics.php؛ SEO 3.5.4)
	$t = hodima_seo_px_limit( 'title' );
	$m = hodima_seo_px_limit( 'description' );
	$n = static fn( int $value ): string => number_format_i18n( $value );

	return $catalog ??= [
		'no_meta'        => [ 'label' => 'بدون توضیح متا', 'level' => 'warn', 'effort' => 1, 'fix' => 'گوگل خلاصه نتیجه را بیشتر از خود متن صفحه می‌سازد و نبود توضیح متا را مشکل نمی‌داند؛ ولی توصیه می‌کند دست‌کم برای صفحه‌های مهم (صفحه اصلی و پربازدیدها) بنویسید. در «{where}» کادر «سئو (SeoBox)» را باز کنید و در «توضیحات متا» توضیحی بنویسید که نوار شمارنده سبز شود (' . $n( $m['min'] ) . ' تا ' . $n( $m['max'] ) . ' پیکسل)؛ کلمه اصلی صفحه در جمله اول بیاید.', 'ref' => 'google:snippet' ],
		'no_snippet'     => [ 'label' => 'متن زیر عنوان ممنوع', 'level' => 'warn', 'effort' => 1, 'fix' => 'در «{where}» کادر «سئو (SeoBox)»، بخش «پیشرفته»، حداکثر طول متن (max-snippet) را روی پیش‌فرض بگذارید؛ مقدار ۰ به گوگل می‌گوید زیر عنوان متنی نشان ندهد و نرخ کلیک را کم می‌کند.', 'ref' => 'google:robots-meta-tag' ],
		'no_h1'          => [ 'label' => 'بدون H1', 'level' => 'warn', 'effort' => 1, 'fix' => 'هر صفحه یک تیتر اصلی (H1) لازم دارد.', 'ref' => 'refs:SEOnaut,SiteOne,FreeCrawl,Yoast' ],
		'no_title'       => [ 'label' => 'بدون عنوان', 'level' => 'warn', 'effort' => 1, 'fix' => 'در «{where}» کادر «سئو (SeoBox)» را باز کنید و «عنوان سئو» بنویسید.', 'ref' => 'google:title-link|refs:SEOnaut,SEOCORE,FreeCrawl' ],
		'title_short'    => [ 'label' => 'عنوان کوتاه', 'level' => 'info', 'effort' => 1, 'fix' => 'گوگل برای طول عنوان حداقلی ندارد؛ اگر عنوان توصیفی و کامل است (مثل «تماس با ما | نام سایت») نیازی به تغییر نیست. فقط اگر عنوان مبهم یا نیمه‌خالی است (مثل «خانه») در «{where}» کادر «سئو (SeoBox)» ← «عنوان سئو» آن را توصیفی‌تر کنید.', 'ref' => 'google:title-link' ],
		'title_long'     => [ 'label' => 'عنوان بلند', 'level' => 'info', 'effort' => 1, 'fix' => 'گوگل برای طول عنوان محدودیتی نمی‌گذارد، ولی عنوان بلندتر از حدود ' . $n( $t['max'] ) . ' پیکسل در نتیجه‌ها بریده می‌شود. اگر بخش مهم عنوان در انتهای آن است، در «{where}» کادر «سئو (SeoBox)» ← «عنوان سئو» را کوتاه کنید یا کلمه اصلی را جلوتر بیاورید.', 'ref' => 'google:title-link' ],
		'dup_title'      => [ 'label' => 'عنوان تکراری', 'level' => 'warn', 'effort' => 2, 'fix' => 'برای هر صفحه عنوان یگانه بنویسید.', 'ref' => 'google:seo-starter-guide|refs:SEOnaut,SiteOne,FreeCrawl,SEOCORE' ],
		'near_dup'       => [ 'label' => 'عنوان مشابه صفحه دیگر', 'level' => 'info', 'effort' => 2, 'fix' => 'عنوان یا H1 این صفحه با صفحه‌های فهرست‌شده یک موضوع را می‌گوید و ممکن است گوگل بین آن‌ها گیج شود (کانیبال). اگر محتوایشان یکی است، یکی را اصلی کنید و دیگری را در «ابزارهای هدیما ← ریدایرکت‌ها» با ۳۰۱ به آن بفرستید. اگر موضوع‌شان جداست، عنوان و H1 را طوری بنویسید که تفاوتشان (نوع، جنس، کاربرد) در آن دیده شود.', 'ref' => 'own' ],
		'dup_h1'         => [ 'label' => 'H1 تکراری', 'level' => 'info', 'effort' => 2, 'fix' => 'تیتر اصلی هر صفحه یگانه باشد.', 'ref' => 'refs:FreeCrawl' ],
		'dup_meta'       => [ 'label' => 'توضیح متای تکراری', 'level' => 'warn', 'effort' => 2, 'fix' => 'گوگل می‌گوید توضیح متای خوب برای یک صفحه یگانه است؛ این صفحه همان توضیح متای صفحه‌های دیگر را دارد و در نتیجه‌های گوگل از هم قابل‌تشخیص نیستند. در «{where}» کادر «سئو (SeoBox)» ← «توضیحات متا» برای همین صفحه توضیح جدا بنویسید.', 'ref' => 'google:seo-starter-guide|refs:SEOnaut,SiteOne,FreeCrawl' ],
		'slow'           => [ 'label' => 'کند', 'level' => 'warn', 'effort' => 3, 'fix' => 'کش و سرعت سرور را بررسی کنید.', 'ref' => 'refs:SEOnaut,SiteOne,FreeCrawl' ],
		'redirect'       => [ 'label' => 'ریدایرکت', 'level' => 'info', 'effort' => 2, 'fix' => 'لینک‌های داخلی را مستقیم به آدرس مقصد بدهید.', 'ref' => 'google:http-network-errors' ],
		'noindex'        => [ 'label' => 'noindex', 'level' => 'info', 'effort' => 1, 'fix' => 'گوگل این صفحه را در نتایج نشان نمی‌دهد. اگر باید در گوگل باشد، در «{where}» کادر «سئو (SeoBox)» ← تب «ایندکس / نوایندکس» (یا افزونه دیگری که noindex گذاشته) آن را بردارید؛ اگر عمدی است کاری لازم نیست.', 'ref' => 'google:robots-meta-tag' ],
		'canonicalised'  => [ 'label' => 'canonical به صفحه دیگر', 'level' => 'info', 'effort' => 1, 'fix' => 'این صفحه با canonical به آدرس دیگری اشاره می‌کند و گوگل همان آدرس را ایندکس می‌کند؛ برای صفحه‌های تکراری و فیلترها درست و مفید است. فقط اگر این صفحه باید خودش در گوگل باشد، canonical را در «{where}» کادر «سئو (SeoBox)» به خود صفحه برگردانید.', 'ref' => 'google:consolidate-duplicate-urls' ],
		'broken'         => [ 'label' => 'صفحه پیدا نمی‌شود (۴xx)', 'level' => 'warn', 'effort' => 2, 'fix' => 'گوگل ۴۰۴ را مشکل نمی‌داند و آدرس را کم‌کم از نتایج برمی‌دارد؛ ولی این آدرس هنوز لینک داخلی یا نمایش گوگل دارد. اگر صفحه عمدا حذف شده، لینک‌های داخلی به آن را درست کنید یا با ریدایرکت ۳۰۱ به صفحه مرتبط بفرستید.', 'ref' => 'refs:SEOnaut,SiteOne,FreeCrawl' ],
		'server_error'   => [ 'label' => 'خطای سرور (۵xx)', 'level' => 'bad', 'effort' => 3, 'fix' => 'سرور برای این آدرس خطای ۵xx می‌دهد؛ گوگل آدرسی را که پیوسته خطای سرور بدهد از ایندکس برمی‌دارد و سرعت خزش سایت را کم می‌کند. علت را در لاگ خطای هاست یا افزونه‌ها پیدا کنید و رفع کنید.', 'ref' => 'google:http-network-errors' ],
		'low_inlinks'    => [ 'label' => 'لینک ورودی کم', 'level' => 'info', 'effort' => 2, 'fix' => 'گوگل برای تعداد لینک ورودی عدد حداقلی ندارد و فقط می‌گوید هر صفحه مهم دست‌کم از یک صفحه دیگر لینک داشته باشد. اگر این صفحه برایتان مهم است، از صفحه‌های مرتبط (دسته، مقاله) به آن لینک متنی بدهید.', 'ref' => 'google:links-crawlable' ],
		'link_broken'    => [ 'label' => 'لینک به صفحه خراب', 'level' => 'warn', 'effort' => 2, 'fix' => 'این صفحه به آدرس‌هایی لینک می‌دهد که خطای ۴۰۴/۵۰۰ می‌دهند؛ هر لینک را به آدرس درست تغییر بدهید یا بردارید.', 'ref' => 'refs:SEOnaut,SiteOne,FreeCrawl' ],
		'link_redirect'  => [ 'label' => 'لینک به ریدایرکت', 'level' => 'info', 'effort' => 2, 'fix' => 'این صفحه به آدرس‌هایی لینک می‌دهد که به جای دیگر می‌روند. گوگل ریدایرکت را دنبال می‌کند (تا ۱۰ پرش) و مشکلی نیست، ولی لینک مستقیم به آدرس مقصد سریع‌تر است؛ در صورت وقت لینک را عوض کنید.', 'ref' => 'google:http-network-errors' ],
		'link_noindex'   => [ 'label' => 'لینک به صفحه ایندکس‌نشدنی', 'level' => 'info', 'effort' => 2, 'fix' => 'در متن این صفحه به صفحه‌ای لینک داده شده که noindex است یا به صفحه دیگری canonical دارد؛ اگر لازم نیست لینک را بردارید یا به آدرس اصلی بدهید.', 'ref' => 'refs:open-seo-crawler' ],
		'redirect_chain' => [ 'label' => 'زنجیره ریدایرکت', 'level' => 'info', 'effort' => 2, 'fix' => 'این آدرس از چند ریدایرکت پشت‌سرهم می‌گذرد؛ گوگل تا ۱۰ پرش را دنبال می‌کند ولی هر پرش کندی و ریسک دارد. ریدایرکت را مستقیم به مقصد نهایی (آدرس زیر) بدهید.', 'ref' => 'google:http-network-errors|refs:SEOnaut,SiteOne,FreeCrawl' ],
		'redirect_loop'  => [ 'label' => 'حلقه ریدایرکت', 'level' => 'bad', 'effort' => 2, 'fix' => 'ریدایرکت‌های این آدرس به هم برمی‌گردند و هیچ‌وقت به صفحه‌ای نمی‌رسند؛ گوگل بعد از ۱۰ پرش دست می‌کشد و صفحه ایندکس نمی‌شود. در «ابزارهای هدیما ← ریدایرکت‌ها» یکی از قانون‌های حلقه را بردارید یا مقصد درست بدهید.', 'ref' => 'google:http-network-errors|refs:SEOnaut,FreeCrawl' ],
		'multi_h1'       => [ 'label' => 'چند H1', 'level' => 'info', 'effort' => 1, 'fix' => 'مستندات گوگل چیزی درباره تعداد H1 نمی‌گوید و ترتیب تیترها را مهم نمی‌داند؛ ولی یک تیتر اصلی روشن برای خواننده بهتر است. اگر قالب چند H1 ساخته، بقیه را H2 کنید.', 'ref' => 'refs:SiteOne,Yoast' ],
		'img_alt'        => [ 'label' => 'تصویر بدون alt', 'level' => 'warn', 'effort' => 2, 'fix' => 'این تصویرهای دیده‌شونده توضیح (alt) ندارند؛ زیر هر تصویر نوشته شده alt را کجا بنویسید و متنی پیشنهاد شده که خودتان می‌خوانید و اصلاح می‌کنید.', 'ref' => 'google:seo-starter-guide|refs:SEOnaut,Yoast' ],
		'img_empty'      => [ 'label' => 'alt خالی (بررسی کنید)', 'level' => 'info', 'effort' => 1, 'fix' => 'این تصویرها alt خالی دارند. برای لوگو، آیکون و تزئین درست است؛ «تزئینی است» را بزنید. اگر تصویر مطلب مهمی نشان می‌دهد (محصول، نمودار) «alt می‌خواهد» را بزنید و برایش توضیح بنویسید.', 'ref' => 'own' ],
		'thin'           => [ 'label' => 'متن کم', 'level' => 'info', 'effort' => 3, 'fix' => 'متن اصلی این صفحه کم است؛ اگر قرار است در گوگل رتبه بگیرد در «{where}» توضیح کامل‌تر اضافه کنید (برای محصول بخش «توضیحات محصول»).', 'ref' => 'google:spam-policies' ],
		'canonical_bad'  => [ 'label' => 'canonical اشتباه', 'level' => 'warn', 'effort' => 2, 'fix' => 'canonical این صفحه به آدرسی اشاره می‌کند که ۲۰۰ نیست یا noindex است؛ آن را به آدرس درست یا خود صفحه برگردانید.', 'ref' => 'refs:SEOnaut,FreeCrawl,open-seo-crawler' ],
		'no_canonical'   => [ 'label' => 'بدون canonical', 'level' => 'info', 'effort' => 2, 'fix' => 'canonical برای گوگل اختیاری است و بدون آن خودش آدرس اصلی را انتخاب می‌کند؛ ولی گوگل «canonical خودارجاع» (به خود صفحه) را توصیه می‌کند. اگر خواستید، در «{where}» کادر «سئو (SeoBox)» آن را فعال کنید.', 'ref' => 'google:consolidate-duplicate-urls' ],
		'canonical_in_body' => [ 'label' => 'canonical بیرون از head', 'level' => 'warn', 'effort' => 2, 'fix' => 'گوگل تگ canonical را فقط داخل بخش head می‌پذیرد؛ در این صفحه آن را داخل body چاپ کرده‌اند و نادیده گرفته می‌شود. معمولا یک افزونه یا قالب بعد از شروع body آن را می‌گذارد؛ آن را به head ببرید یا بردارید و canonical سئوباکس را بگذارید.', 'ref' => 'google:consolidate-duplicate-urls' ],
		'http_link'      => [ 'label' => 'لینک http', 'level' => 'warn', 'effort' => 2, 'fix' => 'در سایت https لینک داخلی با http می‌دهد؛ لینک‌ها را https کنید تا ریدایرکت اضافه نشود.', 'ref' => 'refs:SEOnaut,SiteOne,FreeCrawl' ],
		'sitemap_bad'    => [ 'label' => 'ایراد در نقشه سایت', 'level' => 'warn', 'effort' => 2, 'fix' => 'این آدرس در نقشه سایت است ولی صفحه سالم و ایندکس‌پذیر نیست؛ از نقشه سایت بردارید یا صفحه را درست کنید.', 'ref' => 'google:build-sitemap|refs:SEOnaut,open-seo-crawler' ],
		'site_hidden'    => [ 'label' => 'سایت از گوگل پنهان است', 'level' => 'bad', 'effort' => 1, 'fix' => 'در «تنظیمات ← خواندن» وردپرس گزینه «از موتورهای جستجو بخواه این سایت را ایندکس نکند» روشن است؛ وردپرس روی همه صفحه‌ها noindex می‌گذارد و گوگل هیچ صفحه‌ای را در نتایج نشان نمی‌دهد. اگر سایت باید در گوگل باشد آن گزینه را خاموش کنید.', 'ref' => 'google:robots-meta-tag|refs:RankMath' ],
		'not_in_sitemap' => [ 'label' => 'خارج از نقشه سایت', 'level' => 'info', 'effort' => 1, 'fix' => 'صفحه سالم و ایندکس‌پذیر است ولی در نقشه سایت نیست؛ اگر باید در گوگل باشد به نقشه سایت اضافه کنید.', 'ref' => 'google:build-sitemap' ],
		'deep'           => [ 'label' => 'صفحه عمیق', 'level' => 'info', 'effort' => 2, 'fix' => 'از صفحه اصلی چند کلیک فاصله دارد؛ از صفحه‌های نزدیک‌تر (دسته، مقاله) به آن لینک بدهید.', 'ref' => 'refs:SEOnaut' ],
		'orphan'         => [ 'label' => 'بدون لینک ورودی', 'level' => 'warn', 'effort' => 2, 'fix' => 'گوگل می‌گوید هر صفحه‌ای که برایتان مهم است باید دست‌کم از یک صفحه دیگر سایت لینک داشته باشد؛ از یک یا دو صفحه مرتبط (دسته، مقاله) به آن لینک متنی بدهید.', 'ref' => 'google:links-crawlable|refs:SEOnaut,FreeCrawl' ],
		'island'         => [ 'label' => 'جدا از صفحه اصلی', 'level' => 'info', 'effort' => 2, 'fix' => 'از صفحه اصلی با هیچ مسیر لینکی به این صفحه نمی‌رسیم؛ فقط صفحه‌های جدا از سایت به آن لینک می‌دهند. از منو، صفحه اصلی یا یک صفحه پربازدید (دسته، مقاله) به آن لینک بدهید.', 'ref' => 'own' ],
	];
}

/**
 * دستور یک ایراد با نام «ویرایش» همان نوع صفحه (مثلا «ویرایش محصول»). `$where` خالی = «ویرایش صفحه».
 */
function hodima_seo_advisor_issue_fix( string $code, string $where = '' ): string {

	$fix = (string) ( hodima_seo_advisor_issue_catalog()[ $code ]['fix'] ?? '' );

	return '' === $fix ? '' : str_replace( '{where}', '' !== $where ? $where : 'ویرایش صفحه', $fix );
}

/**
 * نام «ویرایش» نوع صفحه از برچسب‌های خود وردپرس/ووکامرس (مثلا «ویرایش محصول»، «ویرایش دسته»)؛ صفحه اصلی «ویرایش صفحه اصلی».
 * `$kind` نوع نوشته یا طبقه‌بندی (ستون kind جدول آدرس‌ها)؛ خالی = از روتر پیدا می‌شود. بی‌نتیجه = رشته خالی (دستور «ویرایش صفحه» می‌گوید).
 */
function hodima_seo_advisor_issue_where( string $path, string $kind = '' ): string {

	if ( '/' === $path ) {
		return 'ویرایش صفحه اصلی';
	}

	if ( '' === $kind ) {
		$kind = hodima_seo_advisor_classify( $path )['kind'];
	}

	if ( '' !== $kind && post_type_exists( $kind ) ) {
		$object = get_post_type_object( $kind );
		return null !== $object && '' !== (string) $object->labels->edit_item ? (string) $object->labels->edit_item : '';
	}

	if ( '' !== $kind && taxonomy_exists( $kind ) ) {
		$object = get_taxonomy( $kind );
		return null !== $object && '' !== (string) $object->labels->edit_item ? (string) $object->labels->edit_item : '';
	}

	return '';
}
